#ifdef ESP32

#include "GatewayClass.h"
#include "../CommCommand.h"
#include "nvs_flash.h"
#include <Preferences.h>
#include <ETH.h>
#include "../Util.h"
#include <stdexcept>
#include "esp_wpa2.h"


//#define DEBUG_MODE

#ifdef DEBUG_MODE
#define DEBUGPORT Serial
#else
#define DEBUGPORT while(0) Serial
#endif

#ifdef ETH_CLK_MODE
#undef ETH_CLK_MODE
#endif
#define ETH_CLK_MODE    ETH_CLOCK_GPIO0_IN

// Pin# of the enable signal for the external crystal oscillator (-1 to disable for internal APLL source)
#define ETH_POWER_PIN   32
//#define ETH_POWER_PIN   -1

// Type of the Ethernet PHY (LAN8720 or TLK110)
#define ETH_TYPE        ETH_PHY_LAN8720

// I²C-address of Ethernet PHY (0 or 1 for LAN8720, 31 for TLK110)
#define ETH_ADDR        1

// Pin# of the I²C clock signal for the Ethernet PHY
#define ETH_MDC_PIN     23

// Pin# of the I²C IO signal for the Ethernet PHY
#define ETH_MDIO_PIN    18

const char* NTPServer = "time.google.com";
const long GMTOffset = 3600 * 9;
const long DaylightOffset = 0;

_gateway GatewayConfig;
_wifi WifiConfig;
_eth EthConfig;


GatewayClass::GatewayClass(Stream* stream)
{
	mStream = stream;
}

void GatewayClass::ConfigLoad()
{
	WifiLoad();
	EthLoad();
	GatewayLoad();
}

void GatewayClass::ConfigSave()
{
	WifiSave();
	EthSave();
	GatewaySave();
}

void GatewayClass::ConfigReset()
{
	//저장소 공장 초기화
	nvs_flash_erase();
}

void GatewayClass::WifiLoad()
{
	Preferences pref;
	pref.begin("wifi", true);

	WifiConfig.Activate = pref.getBool("activate", false);
	WifiConfig.AuthType = pref.getInt("authtype", 1);
	String SSID = pref.getString("ssid", "vitcon_test");
	strcpy(WifiConfig.SSID, SSID.c_str());
	String Password = pref.getString("password", "12345678");
	strcpy(WifiConfig.Password, Password.c_str());
	String UserID = pref.getString("userid", "");
	strcpy(WifiConfig.UserID, UserID.c_str());
	String UserPW = pref.getString("userpw", "");
	strcpy(WifiConfig.UserPW, UserPW.c_str());

	if ( pref.getBytes("mac", WifiConfig.MAC, 6) <= 0 )
	{
		WifiConfig.MAC[0] = 0x12;
		WifiConfig.MAC[1] = 0x34;
		WifiConfig.MAC[2] = 0x56;
		WifiConfig.MAC[3] = 0x78;
		WifiConfig.MAC[4] = 0x9A;
		WifiConfig.MAC[5] = 0xBC;
	}

	WifiConfig.StaticIP.Enable = pref.getBool("static", false);
	String IP = pref.getString("ip", "0.0.0.0");
	strcpy(WifiConfig.StaticIP.IP, IP.c_str());
	String Gateway = pref.getString("gateway", "0.0.0.0");
	strcpy(WifiConfig.StaticIP.Gateway, Gateway.c_str());
	String Subnet = pref.getString("subnet", "0.0.0.0");
	strcpy(WifiConfig.StaticIP.Subnet, Subnet.c_str());
	String DNS1 = pref.getString("dns1", "0.0.0.0");
	strcpy(WifiConfig.StaticIP.DNS1, DNS1.c_str());
	String DNS2 = pref.getString("dns2", "0.0.0.0");
	strcpy(WifiConfig.StaticIP.DNS2, DNS2.c_str());


	pref.end();
}

void GatewayClass::WifiSave()
{
	Preferences pref;
	pref.begin("wifi");

	pref.putBool("activate", WifiConfig.Activate);
	pref.putInt("authtype", WifiConfig.AuthType);
	pref.putString("ssid", WifiConfig.SSID);
	pref.putString("password", WifiConfig.Password);
	pref.putString("userid", WifiConfig.UserID);
	pref.putString("userpw", WifiConfig.UserPW);
	pref.putBytes("mac", WifiConfig.MAC, 6);

	pref.putBool("static", WifiConfig.StaticIP.Enable);
	pref.putString("ip", WifiConfig.StaticIP.IP);
	pref.putString("gateway", WifiConfig.StaticIP.Gateway);
	pref.putString("subnet", WifiConfig.StaticIP.Subnet);
	pref.putString("dns1", WifiConfig.StaticIP.DNS1);
	pref.putString("dns2", WifiConfig.StaticIP.DNS2);

	pref.end();
}

void GatewayClass::GatewayLoad()
{
	Preferences pref;
	pref.begin("gateway", true);

	GatewayConfig.Status = pref.getBool("status", false);
	GatewayConfig.ReportInterval = pref.getUShort("ri", 60);
	GatewayConfig.MajorVersion = pref.getUShort("mj", 0);
	GatewayConfig.MinorVersion = pref.getUShort("mi", 0);
	GatewayConfig.MaintainVersion = pref.getUShort("ma", 0);

	pref.end();
}

void GatewayClass::GatewaySave()
{
	Preferences pref;
	pref.begin("gateway");

	pref.putBool("status", GatewayConfig.Status);
	pref.putUShort("ri", GatewayConfig.ReportInterval);
	pref.putUShort("mj", GatewayConfig.MajorVersion);
	pref.putUShort("mi", GatewayConfig.MinorVersion);
	pref.putUShort("ma", GatewayConfig.MaintainVersion);


	pref.end();
}


void GatewayClass::EthLoad()
{
	Preferences pref;
	pref.begin("eth", true);

	EthConfig.StaticIP.Enable = pref.getBool("static", false);
	String IP = pref.getString("ip", "0.0.0.0");
	strcpy(EthConfig.StaticIP.IP, IP.c_str());
	String Gateway = pref.getString("gateway", "0.0.0.0");
	strcpy(EthConfig.StaticIP.Gateway, Gateway.c_str());
	String Subnet = pref.getString("subnet", "0.0.0.0");
	strcpy(EthConfig.StaticIP.Subnet, Subnet.c_str());
	String DNS1 = pref.getString("dns1", "0.0.0.0");
	strcpy(EthConfig.StaticIP.DNS1, DNS1.c_str());
	String DNS2 = pref.getString("dns2", "0.0.0.0");
	strcpy(EthConfig.StaticIP.DNS2, DNS2.c_str());

	pref.end();
}

void GatewayClass::EthSave()
{
	Preferences pref;
	pref.begin("eth");

	pref.putBool("static", EthConfig.StaticIP.Enable);
	pref.putString("ip", EthConfig.StaticIP.IP);
	pref.putString("gateway", EthConfig.StaticIP.Gateway);
	pref.putString("subnet", EthConfig.StaticIP.Subnet);
	pref.putString("dns1", EthConfig.StaticIP.DNS1);
	pref.putString("dns2", EthConfig.StaticIP.DNS2);
 
	pref.end();
}

void GatewayClass::Init()
{
  mStream->setTimeout(100);
	ConfigLoad();
	mClearAll();


	EthConnect();

	if (WifiConfig.Activate)
  {
    WifiConnect();
  }

	configTime(GMTOffset, DaylightOffset, NTPServer);

	delay(1000);

	RequestSensorList();
	RequestActuatorList();
}

void GatewayClass::Run()
{
	int ret = mParsing();
	if ( ret == 0 )
  {
		//DEBUGPORT.println(mCmd);
    if ( mCmd == CMD_SENSOR_LIST)
    {
			//센서 리스트를 재설정한다.
      //DEBUGPORT.println("sensorlist");
      mSensorInit(mData, mDataSize);
    }
    else if ( mCmd == CMD_SENSOR_SERIES )
    {
			//시리즈 센서 정보를 업데이트한다.
      //DEBUGPORT.println("series");
      mUpdateSensor(mData, mDataSize);
    }
    else if ( mCmd == CMD_SENSOR_EVENT )
    {
			//이벤트 센서 정보를 업데이트한다.
      //DEBUGPORT.println("event");
      mUpdateSensor(mData, mDataSize, true);
    }
    else if ( mCmd == CMD_ACTUATOR_CONTROL )
    {
			//액추에이터 응답 신호를 처리한다.
			//DEBUGPORT.println("control");
      mActuatorResponse(mData, mDataSize);
    }
		else if ( mCmd == CMD_ACTUATOR_LIST )
    {
			//액추에이터 리스트를 재설정한다.
      //DEBUGPORT.println("actuatorlist");
			mActuatorInit(mData, mDataSize);
    }
    else if ( mCmd >= CMD_WIFI_SSID && CMD_WIFI_GETIP >= mCmd)
    {
			//Wifi 관련 커맨드를 처리한다.
      mWifiCommand();
			//DEBUGPORT.println("wifi cmd");
    }
    else if ( mCmd >= CMD_ETH_STATICIP_USE && CMD_ETH_REFRESH >= mCmd)
    {
			//이더넷 관련 커맨드를 처리한다.
      mEthCommand();
			//DEBUGPORT.println("eth cmd");
    }
    else if ( mCmd >= CMD_GWINFO_ONOFF && CMD_GWINFO_REPORT_INTERVAL  >= mCmd)
    {
			//게이트웨이 정보 관련 커맨드를 처리한다.
      mGwInfoCommand();
			DEBUGPORT.println("gwinfo cmd");
    }
    else if ( mCmd >= CMD_ETC_DATETIME && CMD_ETC_DEVICEID >= mCmd)
    {
			//기타 커맨드를 처리한다.
      mEtcCommand();
			//DEBUGPORT.println("etc cmd");
    }
    else
    {
      DEBUGPORT.println("unknown cmd");
    }
		mLastCommTime = millis();
  }
	else if( ret != -1 )
	{
		//DEBUGPORT.println(ret);
	}

	RequestActuatorRun();
}

uint32_t GatewayClass::GetLastCommTime()
{
	return millis() - mLastCommTime;
}

void GatewayClass::RequestSensorList()
{
  mStream->write(STX);
  mStream->write(CMD_SENSOR_LIST);
  mStream->write((byte)0x00);
  mStream->write(ETX);
}

void GatewayClass::RequestActuatorList()
{
  mStream->write(STX);
  mStream->write(CMD_ACTUATOR_LIST);
  mStream->write((byte)0x00);
  mStream->write(ETX);
}

void GatewayClass::RequestActuatorRun()
{
	if( !mActuatorRequestQueue.empty() )
	{
		//요청 데이터 형태
		//index(1 byte), msgid(36 bytes), ACTUATORDATA(N bytes)
		byte buf[50];

		std::lock_guard<std::mutex> guard(mActuatorRequestQueueLock);
		ActuatorData ad = mActuatorRequestQueue.front();
	
		byte bufsize =  mActuatorFactory.ActuatorGetDeviceData(ad, buf);
		byte index = mActuatorMap[ad.name];

		mStream->write(STX);
		mStream->write(CMD_ACTUATOR_CONTROL);
		mStream->write(bufsize + 1 + 36 );
		mStream->write(index);
		mStream->print(ad.msgid);
		mStream->write(buf, bufsize);
		mStream->write(ETX);

		mActuatorRequestQueue.pop();		
	}
}

int GatewayClass::RunActuator(String id, String msgid, String params)
{
	//서버에서 전송된 actuator id에는 디바이스id가 붙어 있으므로 이를 제거해야 한다.
	//가장 처음 발견하는 '-' 위치의 뒷부분부터 name이다.
	int index = id.indexOf('-');
	String name = id.substring(index + 1);

	if ( mActuatorMap.find(name) == mActuatorMap.end() )
	{
		//호출한 액추에이터가 존재하지 않는 경우이므로 501에러 응답을 보내야 한다.
		return 501;
	}
	else	if( msgid.length() != 36 )
	{
		//메시지 id가 36자가 아닌 경우므로 400에러를 응답.
		return 400;
	}
	else
	{
		ActuatorData a;
		a.name = name;
		a.params = params;
		a.msgid = msgid;

		std::lock_guard<std::mutex> guard(mActuatorRequestQueueLock);
		mActuatorRequestQueue.push(a);
	}
	
	//문제가 없다면 102를 반환.
	return 102;
}

void GatewayClass::mSensorInit(byte* buf, int len)
{
  if ( len < 1 ) return;
  mClearSensor();

  byte count = buf[0];

  int index = 0;
  for (int i = 1; i < len; i += 2 )
  {
    uint16_t sensortype;
    memcpy(&sensortype, &buf[i], 2);

		SensorData sd;
		if( mSensorFactory.MakeSensor(&sd, sensortype) )
		{
			mNewSensorList.push_back(sd);
		}
		
  }

  mListChange = true;
}

void GatewayClass::mActuatorInit(byte* buf, int len)
{
  if ( len < 1 ) return;
  mClearActuator();

  byte count = buf[0];

  int index = 0;
  for (int i = 1; i < len; i += 2 )
  {
    uint16_t type;
    memcpy(&type, &buf[i], 2);

		String name = "";
		
		if( mActuatorFactory.NewMakeActuator(&name, type) )
		{
			mActuatorMap.insert(std::make_pair(name, index));
			mActuatorList.push_back(name);
		}
		index++;
  }

  mListChange = true;
}

void GatewayClass::mUpdateSensor(byte* buf, int len, bool event)
{
	if ( len < 1 ) return;
	byte index = buf[0];

	try
	{
		SensorData* sensor = &mNewSensorList.at(index);

		mSensorFactory.NewUpdateSensor(sensor, buf, len);
	/*
		DEBUGPORT.print(sensor->name);
		DEBUGPORT.print(": ");
		DEBUGPORT.println(sensor->data);
	*/
		if( event )
		{
			std::lock_guard<std::mutex> guard(mEventQueueLock);
			SensorData ed;
			ed.name = sensor->name;
			ed.data = sensor->data;
			ed.time = sensor->time;

			mEventQueue.push(ed);

			//DEBUGPORT.println("이벤트발생");
		}
	}
	catch (const std::out_of_range& oor)
	{
		DEBUGPORT.print("[mUpdateSensor] Out of range: ");
		DEBUGPORT.println(oor.what());
	}
}


void GatewayClass::mActuatorResponse(byte* buf, int len)
{
	if( len != 39 ) return ;

	//액추에이터 응답 신호 DATA의 구성
	//index(1byte), msgid(36bytes), response code(2byte)

	byte index = buf[0];
	char msgid[37];
	uint16_t code;
	memset( msgid, 0, sizeof(msgid) );
	memcpy(msgid, &buf[1], 36);
	memcpy(&code, &buf[37], 2);
/*
	DEBUGPORT.print(msgid);
	DEBUGPORT.print(": ");
	DEBUGPORT.println(code);
*/

	ActuatorData a;
	try
	{
		a.name = mActuatorList.at(index);
	}
	catch (const std::out_of_range& oor)
	{
		DEBUGPORT.print("[mActuatorResponse] Out of range: ");
		DEBUGPORT.println(oor.what());
	}
	
	a.msgid = msgid;
	a.code = code;

	std::lock_guard<std::mutex> guard(mActuatorResponseQueueLock);
	mActuatorResponseQueue.push(a);
}

void GatewayClass::mClearAll()
{
	mClearSensor();
	mClearActuator();
}

int GatewayClass::mParsing()
{
  if ( mStream->available() )
  {
    byte stx = 0, cmd = 0, datalen = 0, etx = 0;
    mStream->readBytes((byte*)&stx, 1);
    if ( stx != STX ) return 1;
    mStream->readBytes((byte*)&cmd, 1);
    mStream->readBytes((byte*)&datalen, 1);
    mStream->readBytes((byte*)mData, datalen);

    mStream->readBytes((byte*)&etx, 1);
    if ( etx != ETX) return 2;

    mDataSize = datalen;
    mCmd = cmd;

    return 0;
  }

  return -1;
}


void GatewayClass::ResetEvent()
{
	std::lock_guard<std::mutex> guard(mEventQueueLock);
	std::queue<SensorData> empty;
	std::swap(mEventQueue, empty);

	//mEventFlag = false;
}

void GatewayClass::EraseBeginEvent()
{
	//std::lock_guard<std::mutex> guard(mEventMapLock);
	std::lock_guard<std::mutex> guard(mEventQueueLock);
	if ( mEventQueue.size() > 0 ) mEventQueue.pop();
	//if ( mEventQueue.size() > 0 ) mEventFlag = true;
	//else mEventFlag = false;
}

void GatewayClass::EraseBeginActuatorResponse()
{
	if( mActuatorResponseQueue.size() > 0 ) mActuatorResponseQueue.pop();
}

bool GatewayClass::ListChanged()
{
	bool b = mListChange;
	mListChange = false;	

	return b;
}

void GatewayClass::mWifiCommand()
{
  byte cmd = mCmd;
  byte *data = mData;
  byte datalen = mDataSize;

  switch (cmd )
  {
    case CMD_WIFI_SSID:
      {
        //SSID를 설정한다.
        memset(WifiConfig.SSID, 0, sizeof(WifiConfig.SSID));
        memcpy(WifiConfig.SSID, data, datalen);
        DEBUGPORT.println(WifiConfig.SSID);
        mResponse(cmd, "OK", 2);
        break;
      }
    case  CMD_WIFI_AUTHTYPE :
      {
        //암호화 타입을 설정한다.
        if ( datalen != 1 )
        {
          mResponse(cmd, "ERR", 3);
        }
        else
        {
          byte b = data[0];
          if ( 0 <= b || b <= 2 )
          {
            WifiConfig.AuthType = b;
            DEBUGPORT.println(WifiConfig.AuthType);
            mResponse(cmd, "OK", 2);
          }
          else
          {
            DEBUGPORT.println("FAIL");
            mResponse(cmd, "ERR", 3);
          }
        }
        break;
      }
    case CMD_WIFI_PASSWORD :
      {
        memset(WifiConfig.Password, 0, sizeof(WifiConfig.Password));
        memcpy(WifiConfig.Password, data, datalen);
        DEBUGPORT.println(WifiConfig.Password);
        mResponse(cmd, "OK", 2);
        break;
      }
    case CMD_WIFI_ENTERPRISE :
      {
        if (datalen != 128 )
        {
          mResponse(cmd, "ERR", 3);
        }
        else
        {
          memset(WifiConfig.UserID, 0, sizeof(WifiConfig.UserID));
          memset(WifiConfig.UserPW, 0, sizeof(WifiConfig.UserPW));
          memcpy(WifiConfig.UserID, data, 64);
          memcpy(WifiConfig.UserPW, &data[64], 64);

          DEBUGPORT.println(WifiConfig.UserID);
          DEBUGPORT.println(WifiConfig.UserPW);
          mResponse(cmd, "OK", 2);
        }
        break;
      }
    case CMD_WIFI_STATICIP_USE :
      {
        if ( datalen != 1 ) mResponse(cmd, "ERR", 3);
        else
        {
          bool b = data[0];
          WifiConfig.StaticIP.Enable = b;
          DEBUGPORT.println((b ? "Static IP" : "DHCP"));
          mResponse(cmd, "OK", 2);
        }
        break;
      }
    case CMD_WIFI_STATICIP_DATA :
      {
        if (datalen != 45 )
        {
          mResponse(cmd, "ERR", 3);
        }
        else
        {
          memset(WifiConfig.StaticIP.IP, 0, sizeof(WifiConfig.StaticIP.IP));
          memset(WifiConfig.StaticIP.Gateway, 0, sizeof(WifiConfig.StaticIP.Gateway));
          memset(WifiConfig.StaticIP.Subnet, 0, sizeof(WifiConfig.StaticIP.Subnet));
          memcpy(WifiConfig.StaticIP.IP, data, 15);
          memcpy(WifiConfig.StaticIP.Subnet, &data[15], 15);
          memcpy(WifiConfig.StaticIP.Gateway, &data[30] , 15);
          DEBUGPORT.println(WifiConfig.StaticIP.IP);
          DEBUGPORT.println(WifiConfig.StaticIP.Gateway);
          DEBUGPORT.println(WifiConfig.StaticIP.Subnet);
          mResponse(cmd, "OK", 2);
        }
        break;
      }
    case CMD_WIFI_STATICIP_DNS :
      {
        if (datalen != 30 )
        {
          mResponse(cmd, "ERR", 3);
        }
        else
        {
          memset(WifiConfig.StaticIP.DNS1, 0, sizeof(WifiConfig.StaticIP.DNS1));
          memset(WifiConfig.StaticIP.DNS2, 0, sizeof(WifiConfig.StaticIP.DNS2));
          memcpy(WifiConfig.StaticIP.DNS1, data, 15);
          memcpy(WifiConfig.StaticIP.DNS2, &data[15] , 15);
          DEBUGPORT.println(WifiConfig.StaticIP.DNS1);
          DEBUGPORT.println(WifiConfig.StaticIP.DNS2);
          mResponse(cmd, "OK", 2);
        }
        break;
      }
    case CMD_WIFI_START :
      {
        //WifiConfig.Activate = true;
				//WifiConnect();
				WifiOn();
        DEBUGPORT.println("WIFI START");
        mResponse(cmd, "OK", 2);
        break;
      }
    case CMD_WIFI_STOP :
      {
        //WifiConfig.Activate = false;
        //WiFi.disconnect();
				WifiOff();
        DEBUGPORT.println("WIFI STOP");
        mResponse(cmd, "OK", 2);
        break;
      }
    case CMD_WIFI_GETIP :
      {
        char buf[45];
        String ip = WiFi.localIP().toString();
        String subnet = WiFi.subnetMask().toString();
        String gateway = WiFi.gatewayIP().toString();

        memset(buf, 0, sizeof(buf));
        memcpy(buf, ip.c_str(), 15);
        memcpy(&buf[15], subnet.c_str(), 15);
        memcpy(&buf[30], gateway.c_str(), 15);

        mResponse(cmd, buf, sizeof(buf));
        break;
      }
    default :
      DEBUGPORT.println("cmd not defined");
      return;
  }

  WifiSave();
}

void GatewayClass::mEthCommand()
{
  byte cmd = mCmd;
  byte *data = mData;
  byte datalen = mDataSize;

  switch ( cmd)
  {
    case CMD_ETH_STATICIP_USE :
      {
        if ( datalen != 1 )
				{
					mResponse(cmd, "ERR", 3);
					DEBUGPORT.print("length err(req 1):" );
					DEBUGPORT.println(datalen);
				}
        else
        {
          bool b = data[0];
          EthConfig.StaticIP.Enable = b;
          DEBUGPORT.println((b ? "Static IP" : "DHCP"));
          mResponse(cmd, "OK", 2);
        }
        break;
      }
    case CMD_ETH_STATICIP_DATA  :
      {
        if (datalen != 45 )
        {
          mResponse(cmd, "ERR", 3);
					DEBUGPORT.print("length err(req 45):" );
					DEBUGPORT.println(datalen);
        }
        else
        {
          memset(EthConfig.StaticIP.IP, 0, sizeof(EthConfig.StaticIP.IP));
          memset(EthConfig.StaticIP.Gateway, 0, sizeof(EthConfig.StaticIP.Gateway));
          memset(EthConfig.StaticIP.Subnet, 0, sizeof(EthConfig.StaticIP.Subnet));
          memcpy(EthConfig.StaticIP.IP, data, 15);
          memcpy(EthConfig.StaticIP.Subnet, &data[15], 15);
          memcpy(EthConfig.StaticIP.Gateway, &data[30] , 15);
          DEBUGPORT.println(EthConfig.StaticIP.IP);
          DEBUGPORT.println(EthConfig.StaticIP.Gateway);
          DEBUGPORT.println(EthConfig.StaticIP.Subnet);
          mResponse(cmd, "OK", 2);
        }
        break;
      }
    case CMD_ETH_STATICIP_DNS :
      {
        if (datalen != 30 )
        {
          mResponse(cmd, "ERR", 3);
					DEBUGPORT.print("length err(req 30):" );
					DEBUGPORT.println(datalen);
        }
        else
        {
          memset(EthConfig.StaticIP.DNS1, 0, sizeof(EthConfig.StaticIP.DNS1));
          memset(EthConfig.StaticIP.DNS2, 0, sizeof(EthConfig.StaticIP.DNS2));
          memcpy(EthConfig.StaticIP.DNS1, data, 15);
          memcpy(EthConfig.StaticIP.DNS2, &data[15] , 15);
          DEBUGPORT.println(EthConfig.StaticIP.DNS1);
          DEBUGPORT.println(EthConfig.StaticIP.DNS2);
          mResponse(cmd, "OK", 2);
        }
        break;
      }
		case CMD_ETH_GETIP:
		{
			char buf[45];
			String ip = ETH.localIP().toString();
			String subnet = ETH.subnetMask().toString();
			String gateway = ETH.gatewayIP().toString();

			memset(buf, 0, sizeof(buf));
			memcpy(buf, ip.c_str(), 15);
			memcpy(&buf[15], subnet.c_str(), 15);
			memcpy(&buf[30], gateway.c_str(), 15);

			mResponse(cmd, buf, sizeof(buf));
			//DEBUGPORT.println("send ok");
			break;
		}
		case CMD_ETH_REFRESH:
		{
			EthRefresh();
			mResponse(cmd, "OK", 2);
			break;
		}
    default:
      DEBUGPORT.println("cmd not defined");
      return;
  }

	EthSave();
}

void GatewayClass::mGwInfoCommand()
{
	byte cmd = mCmd;
  byte *data = mData;
  byte datalen = mDataSize;

	switch ( cmd)
  {
		case CMD_GWINFO_ONOFF:
		{
			DEBUGPORT.println("Gateway start");
			bool b = data[0];
			GatewayConfig.Status = b;
			mResponse(cmd, "OK", 2);
			break;
		}
		case CMD_GWINFO_REPORT_INTERVAL:
		{
			DEBUGPORT.println("Set interval");
			uint16_t interval;
			memcpy(&interval, &data[0], 2);
			
			if( interval < 1 ) interval = 1;
			GatewayConfig.ReportInterval = interval;

			mResponse(cmd, "OK", 2);
			break;
		}
		default:
			DEBUGPORT.println("cmd not defined");
			return;
	}

}

void GatewayClass::mEtcCommand()
{
	byte cmd = mCmd;
  byte *data = mData;
  byte datalen = mDataSize;

  switch ( cmd)
  {
    case CMD_ETC_HELLO :
      {
				DEBUGPORT.println(("Mega Hello"));
				mResponse(cmd, "OK", 2);
			
        break;
      }
    case CMD_ETC_DATETIME  :
      {
				DEBUGPORT.println("Datetime");
				time_t now = time(0); //현재 시간을 time_t 타입으로 저장
				struct tm tstruct;
				char buf[20];
				tstruct = *localtime(&now);
				strftime(buf, sizeof(buf), "%Y-%m-%d %X", &tstruct); //yyyy-mm-dd hh:mm:ss

				mResponse(cmd, buf, 19);
				break;
      }
    case CMD_ETC_UNIXTIME :
      {
				DEBUGPORT.println("Unixtime");
				time_t nt;
				time(&nt);

				String str = String(nt);
				char buf[10];
				memset(buf, 0, sizeof(buf));
				memcpy(buf, str.c_str(), 10);

				mResponse(cmd, buf, sizeof(buf));
        
        break;
      }
		case CMD_ETC_DEVICEID:
		{
			DEBUGPORT.println("DeviceID");
			char buf[13];
			uint8_t baseMac[6];
			// Get MAC address for ETH
			esp_read_mac(baseMac, ESP_MAC_ETH);
			sprintf(buf, "%02X%02X%02X%02X%02X%02X", baseMac[0], baseMac[1], baseMac[2], baseMac[3], baseMac[4], baseMac[5]);
			mResponse(cmd, buf, 12);
			break;
		}
		case CMD_ETH_REFRESH:
		{
			EthRefresh();
			mResponse(cmd, "OK", 2);
			break;
		}
    default:
      DEBUGPORT.println("cmd not defined");
      return;
  }
}

void GatewayClass::mResponse(byte cmd, const char* data, byte datalen)
{
  mStream->write(STX);
  mStream->write(cmd);
  mStream->write(datalen);
  mStream->write(data, datalen);
  mStream->write(ETX);
}

void GatewayClass::EthConnect()
{
	ETH.begin(ETH_ADDR, ETH_POWER_PIN, ETH_MDC_PIN, ETH_MDIO_PIN, ETH_TYPE, ETH_CLK_MODE);
	EthRefresh();
}

void GatewayClass::EthRefresh()
{
	IPAddress localip(0, 0, 0, 0);
	IPAddress gateway(0, 0, 0, 0);
	IPAddress subnet(0, 0, 0, 0);
	IPAddress dns1(0, 0, 0, 0);
	IPAddress dns2(0, 0, 0, 0);

	if( EthConfig.StaticIP.Enable )
	{
		localip.fromString(EthConfig.StaticIP.IP);
    gateway.fromString(EthConfig.StaticIP.Gateway);
    subnet.fromString(EthConfig.StaticIP.Subnet);
    dns1.fromString(EthConfig.StaticIP.DNS1);
    dns2.fromString(EthConfig.StaticIP.DNS2);		
	}

	ETH.config(localip, gateway, subnet, dns1, dns2);
}

void GatewayClass::WifiConnect()
{
	WiFi.disconnect();
  WiFi.mode(WIFI_STA);

  IPAddress localip(0, 0, 0, 0);
  IPAddress gateway(0, 0, 0, 0);
  IPAddress subnet(0, 0, 0, 0);
  IPAddress dns1(0, 0, 0, 0);
  IPAddress dns2(0, 0, 0, 0);

  if ( WifiConfig.StaticIP.Enable )
  {
    localip.fromString(WifiConfig.StaticIP.IP);
    gateway.fromString(WifiConfig.StaticIP.Gateway);
    subnet.fromString(WifiConfig.StaticIP.Subnet);
    dns1.fromString(WifiConfig.StaticIP.DNS1);
    dns2.fromString(WifiConfig.StaticIP.DNS2);
  }
  WiFi.config(localip, gateway, subnet, dns1, dns2);

  DEBUGPORT.println();
  DEBUGPORT.println();
  DEBUGPORT.print("Connecting to ");
  DEBUGPORT.println(WifiConfig.AuthType);
  DEBUGPORT.println(WifiConfig.SSID);
  DEBUGPORT.println(WifiConfig.Password);
  DEBUGPORT.println(WifiConfig.UserID);
  DEBUGPORT.println(WifiConfig.UserPW);

  //WiFi.begin(WifiConfig.SSID, WifiConfig.Password);
  if ( WifiConfig.AuthType == WIFI_AUTHTYPE_WPA2_ENTERPRISE)
  {
    String SSID = String(WifiConfig.SSID);
    String ID = String(WifiConfig.UserID);
    String PW = String(WifiConfig.UserPW);

    esp_wifi_sta_wpa2_ent_set_identity((uint8_t *)(ID.c_str()), strlen(ID.c_str())); //provide identity
    esp_wifi_sta_wpa2_ent_set_username((uint8_t *)(ID.c_str()), strlen(ID.c_str())); //provide username
    esp_wifi_sta_wpa2_ent_set_password((uint8_t *)(PW.c_str()), strlen(PW.c_str())); //provide password
    esp_wpa2_config_t config = WPA2_CONFIG_INIT_DEFAULT();
    esp_wifi_sta_wpa2_ent_enable(&config);
    WiFi.begin(SSID.c_str());
  }
  else if ( WifiConfig.AuthType == WIFI_AUTHTYPE_ENCRYPT )
  {
    String SSID = String(WifiConfig.SSID);
    String Password = String(WifiConfig.Password);
    WiFi.begin(SSID.c_str(), Password.c_str());
  }
  else
  {
    String SSID = String(WifiConfig.SSID);
    WiFi.begin(SSID.c_str());
  }
}

void GatewayClass::WifiOn()
{
	WifiConfig.Activate = true;
	WifiConnect();
	WifiSave();
}

void GatewayClass::WifiOff()
{
	WifiConfig.Activate = false;
	WiFi.disconnect();
  WifiSave();
}

#endif