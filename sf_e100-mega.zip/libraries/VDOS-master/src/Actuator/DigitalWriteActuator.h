/*
	디지털 출력 액추에이터
	제어가능한 디지털 출력포트가 있을 경우 해당 출력 상태를 변경할 때 호출하는 액추에이터

	cmd: "on", "off"
	params: 둘 다 없음
	callback함수 형태: void func(const char*, bool*);
*/
#pragma once

#include "ActuatorClass.h"

class DigitalWriteActuator : public ActuatorClass
{
	public:
		DigitalWriteActuator(bool (*func)(const char*)) : ActuatorClass()
		{
			mFunc = func;
			mActuatorType = ACTUATOR_DIGITALWRITE;
		}

		virtual bool Activate(byte* buf)
		{
			byte cmd = buf[0];
			String str = "";
			
			if( cmd == 1 )  str = "on";
			else str= "off";

			bool b = mFunc(str.c_str());
			
			return b;
		}

	private:
		//콜백함수
		//cmd: 호출 커맨드
		//반환값: 처리 결과
		bool (* mFunc)(const char* cmd); //콜백함수
		 
};