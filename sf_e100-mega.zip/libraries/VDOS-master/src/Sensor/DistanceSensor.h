/*
	거리 센서
	거리를 표시하는데 사용하는 센서로 데이터는 실수 이다.
	데이터 타입: float
*/
#pragma once

#include "SensorClass.h"

class DistanceSensor : public SensorClass
{
	public:
		DistanceSensor() : SensorClass()
		{
			mSensorType = SENSOR_DISTANCE;
			mLength = sizeof(float);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(float data)
		{
			mData = data;
		} 
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		float mData;
};
