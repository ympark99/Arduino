/*
	온오프 센서
	뭔가의 온오프 상태를 표시하는데 사용하는 이벤트 센서이다. 데이터는 bool이며 현재 상태에 따라 특정한 enum이 발생한다.

	event data:
	데이터가 false->true로 바뀔 때 "on" 발생.
	데이터가 true->false로 바뀔 때 "off" 발생.
	
	series data:
	데이터가 false인 경우 "off" 발생.
	데이터가 true인 경우 "on" 발생.

*/
#pragma once

#include "SensorClass.h"

class OnoffSensor : public SensorClass
{
	public:
		OnoffSensor(bool event = true): SensorClass()
		{
			mSensorType = SENSOR_ONOFF;
			mLength = sizeof(bool);
			mData = false;
			mIsEvent = event;
			mChanged = false;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(bool data)
		{
			if ( mData != data )
			{
				mData = data;
				if ( mIsEvent ) mChanged = true;
			}
		}
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}
		virtual bool Changed()
		{
			return mChanged;
		}
		virtual void EventSended()
		{
			mChanged = false;
		}


	private:
		bool mData;
		bool mChanged;
};
