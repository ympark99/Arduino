#ifdef ESP32

#include "ActuatorFactory.h"
#include "../Util.h"
#include "../Actuators.h"
#include "../ArduinoJson/ArduinoJson-v6.14.1.h"

#define ERROR_PARSING_FAIL -1
#define ERROR_MISSING_KEY_CMD -2
#define ERROR_INCORRECT_CMD -3

bool ActuatorFactory::NewMakeActuator(String* name, uint16_t type)
{
	String temp = "";
	switch ( type )
	{
		case ACTUATOR_COUNTRESET:
		{
			temp = "countreset";
			break;
		}
		case ACTUATOR_DIGITALWRITE:
		{
			temp = "digitalwrite";
			break;
		}

		default:
		{
			return false;
			break;
		}
	}

	(*name) = temp + "-" + String(mActuatorCount[temp]);
	mActuatorCount[temp]++;

	return true;
}

int ActuatorFactory::ActuatorGetDeviceData(ActuatorData actuator, byte* buf)
{
	long type	= mGetActuatorType(actuator.name);
	String params = actuator.params;
	byte bufsize = 0;

	DynamicJsonDocument root(512);

	switch (type)
	{
		case ACTUATOR_COUNTRESET:
		{
			//카운트리셋 액추에이터: cmd(1byte), cmd 0 고정
			bufsize = 1;

			buf[0] = 0;


			break;
		}
		case ACTUATOR_DIGITALWRITE:
		{
			//디지털출력 액추에이터: cmd(1byte)
			bufsize = 1;

			auto error = deserializeJson(root, params);
			
			if( error ) return ERROR_PARSING_FAIL; //json 파싱 실패

			JsonVariant check;
			check = root["cmd"];
			if( check.isNull() ) return ERROR_MISSING_KEY_CMD; //cmd key 누락

			//cmd가 "off"인 경우 0, "on"인 경우 1을 전송
			String cmd = check;
			if( cmd.equals("off") ) buf[0] = 0;
			else if ( cmd.equals("on") ) buf[0] = 1;
			else return ERROR_INCORRECT_CMD;
			

			

			break;
		}
		default:
		{
			return 0;

			break;
		}
	
	}
	//버퍼 사이즈를 리턴
	return bufsize;
}

unsigned short ActuatorFactory::mGetActuatorType(String name)
{
	if( name.indexOf("countreset") >= 0)
	{
		return ACTUATOR_COUNTRESET;
	}
	else if ( name.indexOf("digitalwrite") >= 0 )
	{
		return ACTUATOR_DIGITALWRITE;
	}

	return 0xffff;
}

void ActuatorFactory::JsonTest()
{
	DynamicJsonDocument doc(1024);
	doc["key"] = "value";
	doc["raw"] = serialized("[1,2,3]");
	serializeJson(doc, Serial);
}


#endif