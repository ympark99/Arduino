#pragma once

#include "DeviceClass.h"
#ifdef ESP32
#include "ESP32/GatewayClass.h"
#endif
#include "Sensors.h"
#include "Actuators.h"