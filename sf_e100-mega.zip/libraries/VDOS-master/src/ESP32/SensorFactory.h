#pragma once

#ifdef ESP32
#include <map>
#include <Arduino.h>

struct SensorData
{
	String name; //JSON에 사용하는 센서 이름
	String data; //JSON에 사용하는 데이터
	uint64_t time; //JSON에 사용하는 시간
	bool event; //이벤트 센서 여부
};

class SensorFactory
{
	public:
		SensorFactory() {}
	
		bool MakeSensor(SensorData* sensor, uint16_t type); //리스트에 넣을 새로운 센서 정보를 만든다.
		void NewUpdateSensor(SensorData* sensor, byte* buf, int len); //센서 정보를 업데이트한다.
		
		void Clear() //생성 수량을 초기화한다.
		{
			mSensorCount.clear();
		}
					
	private:
		std::map<String, int> mSensorCount; //생성한 센서 개수를 가지고 있는다.
		

};

#endif