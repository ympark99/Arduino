/*
	문자열 센서
	문자열을 표시하는데 사용하는 센서로 데이터는 문자열 이다.
	데이터 타입: char[50]
*/
#pragma once

#include "SensorClass.h"

class StringSensor : public SensorClass
{
	public:
		StringSensor() : SensorClass()
		{
			mSensorType = SENSOR_STRING;
			mLength = 0;
			memset(mData, 0, sizeof(mData));
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, mData, mLength);

			return mLength;
		}
		virtual void SetData(const char* data)
		{
			int len = strlen(data);
			memcpy(mData, data, len);
			mLength = len;
		}
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}

	private:
		char mData[50];
};
