/*
	펄스 센서
	뭔가가 Active 되었다는 것을 알리는 이벤트 센서이다.  데이터는 bool이며 현재 상태에 따라 특정한 enum이 발생한다.

	event data:
	데이터가 false->true로 바뀔 때 "activate" 발생.

	series data:
	"deactivate" 발생.
*/

#pragma once

#include "SensorClass.h"

class PulseSensor : public SensorClass
{
	public:
		PulseSensor(bool event = true): SensorClass()
		{
			mSensorType = SENSOR_PULSE;
			mLength = sizeof(bool);
			mData = false;
			mIsEvent = event;
			mActivate = false;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(bool data)
		{
			if ( mData != data )
			{
				mData = data;
				if ( mIsEvent )
				{
					if( mData ) mActivate = true;
				}
			}
		}
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}
		virtual bool Changed()
		{
			return mActivate;
		}
		virtual void EventSended()
		{
			mActivate = false;
		}


	private:
		bool mData;
		bool mActivate;
};
