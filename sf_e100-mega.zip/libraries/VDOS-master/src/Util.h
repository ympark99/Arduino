#ifdef ESP32

#include "sys/time.h"
#include <Arduino.h>

inline uint64_t GetTimestamp()
{
 struct timeval tv;
  gettimeofday(&tv, NULL);

  uint64_t val = ((uint64_t)tv.tv_sec * 1000) + (tv.tv_usec / 1000);

  return val;
}

#endif