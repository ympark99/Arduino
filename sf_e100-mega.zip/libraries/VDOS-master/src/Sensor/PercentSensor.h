/*
	퍼센트 센서
	퍼센트 수치를 표시하는데 사용하는 센서로 데이터는 실수 이다.
	데이터 타입: float
*/
#pragma once

#include "SensorClass.h"

class PercentSensor : public SensorClass
{
	public:
		PercentSensor() : SensorClass()
		{
			mSensorType = SENSOR_PERCENT;
			mLength = sizeof(float);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(float data)
		{
			//소수점 한자리로 자른다.
			int temp = data * 10;
			mData = temp/10.0;
		} 
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		float mData;
};
