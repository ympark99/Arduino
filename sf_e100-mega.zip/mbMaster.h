/*
 * Modbus Master Designed by Doan Phuc Thinh
 * V2.0 for MCU Mega
 * Start : 2019-07-19 using original ModbusMaster Library https://github.com/4-20ma/ModbusMaster
*/

#ifndef _MBMASTER_H
#define _MBMASTER_H

#include <ModbusMaster.h>
#include "Arduino.h"
#include "remoteData.h"

#define ID_AS_SLAVE1 1
#define ID_AS_SLAVE2 20
#define ID_AS_SLAVE3 21
#define ID_AS_SLAVE4 22
#define ID_AS_SLAVE5 23


// Index in excel file plus 1
#define BIT_SLAVE1_ADDRESS     5000
#define BIT_SLAVE1_READSIZE    19
#define DATA_SLAVE1_ADDRESS    6000
#define DATA_SLAVE1_READSIZE   16

#define BIT_SLAVE2_ADDRESS     30720
#define BIT_SLAVE2_READSIZE    25
#define DATA_SLAVE2_ADDRESS    30720
#define DATA_SLAVE2_READSIZE   77

#define BIT_SLAVE3_ADDRESS     30720
#define BIT_SLAVE3_READSIZE    17
#define DATA_SLAVE3_ADDRESS    30720
#define DATA_SLAVE3_READSIZE   12

#define BIT_SLAVE4_ADDRESS     0
#define BIT_SLAVE4_READSIZE    19
#define DATA_SLAVE4_ADDRESS    0
#define DATA_SLAVE4_READSIZE   4

#define BIT_SLAVE5_ADDRESS     0
#define BIT_SLAVE5_READSIZE    14
#define DATA_SLAVE5_ADDRESS    0
#define DATA_SLAVE5_READSIZE   4



class mbMaster {
  
  public:
  mbMaster();
  void init();
  void run();


  private:

  void remoteDataUpdate();
  
  // Slave1 Submodlink (Loading)
  ModbusMaster Master1;
  void ProcessSlave1();

  // Slave2 Mitsubishi PLC1 (Shuttle)
  ModbusMaster Master2;
  void ProcessSlave2();

  // Slave3 Mitsubishi PLC2 (Measuring)
  ModbusMaster Master3;
  void ProcessSlave3();


  // Slave4 LS PLC1 (Unloading)
  ModbusMaster Master4;
  void ProcessSlave4();

  // Slave5 LS PLC2 (Return)
  ModbusMaster Master5;
  void ProcessSlave5();
  
};

extern mbMaster mbMaster1;


#endif
