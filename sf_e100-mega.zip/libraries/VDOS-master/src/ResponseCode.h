#pragma once

//정보
const unsigned short RESPONSE_PROCESSING = 102; //처리중

//성공
const unsigned short RESPONSE_SUCCESS = 200; //성공

//오류
const unsigned short RESPONSE_BAD_REQUEST = 400; //필수 값이 누락되었거나 서버에서 잘못된 값을 보냄
const unsigned short RESPONSE_FORBIDDEN = 403; //해당 명령을 수행할 수 있는 권한이 없음
const unsigned short RESPONSE_TIMEOUT = 408; //타임아웃. 명령을 수행하려 하였으나 응답이 없음.
const unsigned short RESPONSE_NOT_IMPLEMENTED = 501; //해당 명령이 존재하지 않음.
const unsigned short RESPONSE_SERVICE_UNAVAILABLE = 503; //게이트웨이의 상태가 off이기 때문에 명령을 수행할 수 없음
