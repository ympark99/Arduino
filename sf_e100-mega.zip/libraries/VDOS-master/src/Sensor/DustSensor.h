/*
	먼지 센서
	먼지 농도를 표시하는데 사용하는 센서로 데이터는 0 또는 양의 정수 이다.
	데이터 타입: unsigned short
*/
#pragma once

#include "SensorClass.h"

class DustSensor : public SensorClass
{
	public:
		DustSensor() : SensorClass()
		{
			mSensorType = SENSOR_DUST;
			mLength = sizeof(unsigned short);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(unsigned short data)
		{
			mData = data;
		} 
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		unsigned short mData;
};
