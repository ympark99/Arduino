/*
	시간 센서
	unix time을 표시하는데 사용하는 센서로 데이터는 64비트 정수 이다.
	데이터 타입: unsigned long long
*/
#pragma once

#include "SensorClass.h"

class TimeSensor : public SensorClass
{
	public:
		TimeSensor() : SensorClass()
		{
			mSensorType = SENSOR_TIME;
			mLength = sizeof(unsigned long long);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(unsigned long long data)
		{
			mData = data;
		}
		virtual void PrintData()
		{
			Print64(mData);
			
			DEBUGPORT.println();
		}
		void Print64(unsigned long long num)
		{	
			int digit = num % 10;

			if( num > 9 ) Print64(num / 10);
			DEBUGPORT.print(digit);
		}

	private:
		unsigned long long mData;
};
