/*
	수집장치-게이트웨이 간 통신 커맨드
	2020-03-10 jjh
*/

#pragma once

//Data CMD
const static byte CMD_SENSOR_LIST = 0x14; //센서 리스트
const static byte CMD_SENSOR_SERIES = 0x15; //센서 시리즈 데이터
const static byte CMD_SENSOR_EVENT = 0x16; //센서 이벤트 데이터
const static byte CMD_ACTUATOR_CONTROL = 0x17; //액추에이터 제어/응답
const static byte CMD_ACTUATOR_LIST = 0x18; //액추에이터 리스트

//이 아래부터는 Mega에서 ESP32를 제어하기 위해 사용하는 커맨드.
//WiFi CMD
const static byte CMD_WIFI_SSID = 0x20;
const static byte CMD_WIFI_AUTHTYPE = 0x21; //AP 암호화 방식 설정. 0x00: OPEN, 0x01: WPA2, 0x02: 기업형보안
const static byte CMD_WIFI_PASSWORD = 0x22;
const static byte CMD_WIFI_ENTERPRISE = 0x23; //기업형보안 사용자이름 및 암호 정보
const static byte CMD_WIFI_STATICIP_USE = 0x24; //고정IP 사용여부
const static byte CMD_WIFI_STATICIP_DATA = 0x25; //고정IP 설정정보. 고정IP 사용시 필수사항.
const static byte CMD_WIFI_STATICIP_DNS = 0x26; //고정IP DNS정보. 고정IP 사용시 선택사항.
const static byte CMD_WIFI_START = 0x27; //Wifi 연결 및 재접속 루틴 시작.
const static byte CMD_WIFI_STOP = 0x28; //Wifi 연결해제 및 재접속 루틴 종료.
const static byte CMD_WIFI_GETIP = 0x29; //Wifi 현재 IP정보 요청.

//Ethernet CMD
const static byte CMD_ETH_STATICIP_USE = 0x30; //고정IP 사용여부
const static byte CMD_ETH_STATICIP_DATA  = 0x31; //고정IP 설정정보. 고정IP 사용시 필수사항.
const static byte CMD_ETH_STATICIP_DNS = 0x32; //고정IP DNS정보. 고정IP 사용시 필수사항.
const static byte CMD_ETH_GETIP = 0x33; //Ethernet 현재 IP정보 요청.
const static byte CMD_ETH_REFRESH = 0x34; //Ethernet 고정IP 변경시 설정 적용.

//Gateway Info
const static byte CMD_GWINFO_ONOFF = 0x40; //게이트웨이 시작여부 설정.
const static byte CMD_GWINFO_REPORT_INTERVAL = 0x41; //게이트웨이 전송주기 설정.

//ETC Info
const static byte CMD_ETC_HELLO = 0x50; //ESP32 응답 확인
const static byte CMD_ETC_DATETIME = 0x51; //날짜 포맷 시간 가져오기
const static byte CMD_ETC_UNIXTIME = 0x52; //unix timestamp 가져오기
const static byte CMD_ETC_DEVICEID = 0x53; //Device ID 가져오기(Wifi STA MAC)