/*
	LED 센서
	LED의 온오프 상태를 표시하는데 사용하는 센서이다. 데이터는 bool이며 현재 상태에 따라 특정한 enum이 발생한다.
	
	series data:
	LED가 false인 경우 "off" 발생.
	LED가 true인 경우 "on" 발생.

*/
#pragma once

#include "SensorClass.h"

class LEDSensor : public SensorClass
{
	public:
		LEDSensor(): SensorClass()
		{
			mSensorType = SENSOR_LED;
			mLength = sizeof(bool);
			mData = false;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(bool data)
		{
				mData = data;
		}
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		bool mData;
};
