/**
 * Created by Doan, Phuc Thinh on 2019-04-05.
 * Last Revision: 2019-04-05
 *
 * Description in control.h
 * 
 */

 #include "control.h"

using namespace vitcon_ctr;



sgEdge::sgEdge() {}
sgDelay::sgDelay() {}
sgMinTime::sgMinTime() {}
sgClock::sgClock() {}
stControl::stControl() {}
stCountIncDec::stCountIncDec() {}
stFilter::stFilter() {}
stControlMode::stControlMode() {}

/*
 * ************************************************************************************************
  Rissing Edge Signal
 * ************************************************************************************************
*/
bool sgEdge::Rise(bool data) {
  if (data && !mRiseEdge) {
    mRiseEdge = true;
    return true;
  }else if (!data && mRiseEdge) {
    mRiseEdge = false;
    return false;
  }else {
    return false;
  }  
}

/*
 * ************************************************************************************************
  Falling Edge Signal
 * ************************************************************************************************
*/
bool sgEdge::Fall(bool data) {
  if (data && !mFallEdge) {
    mFallEdge = true;
    return false;
  }else if (!data && mFallEdge) {
    mFallEdge = false;
    return true;
  }else {
    return false;
  }  
}

/*
 * ************************************************************************************************
  Rissing Edge Close Signal
 * ************************************************************************************************
*/
bool sgEdge::RiseClose(bool data) {
  data = !data;
  if (data && !mRiseCloseEdge) {
    mRiseCloseEdge = true;
    return true;
  }else if (!data && mRiseCloseEdge) {
    mRiseCloseEdge = false;
    return false;
  }else {
    return false;
  }  
}

/*
 * ************************************************************************************************
  Falling Edge Close Signal
 * ************************************************************************************************
*/
bool sgEdge::FallClose(bool data) {
  data = !data;
  if (data && !mFallCloseEdge) {
    mFallCloseEdge = true;
    return false;
  }else if (!data && mFallCloseEdge) {
    mFallCloseEdge = false;
    return true;
  }else {
    return false;
  }  
}

/*
 * ************************************************************************************************
  On Delay Signal
 * ************************************************************************************************
*/
bool sgDelay::dON(bool data,uint32_t timedelay) {
  uint32_t curr = millis();
  if(curr < mOnTime) mOnTime =0;
  
  if(data) 
  {
    if((curr - mOnTime) > timedelay)  return true;
    else return false; 
  }
  else 
  {
    mOnTime = millis();
    return false;
  }
}

/*
 * ************************************************************************************************
  Off Delay Signal
 * ************************************************************************************************
*/
bool sgDelay::dOFF(bool data,uint32_t timedelay) {
  uint32_t curr = millis();
  if(curr < mOffTime) mOffTime =0;
  
  if(data) 
  {     
    mOffDelay = true; 
    mOffTime = millis();
    return true; 
  } 
  else 
  {
    if(mOffDelay) {
      if((curr - mOffTime) < timedelay) return true;
    }
  }
  mOffDelay = false; 
  return false;
}

/*
 * ************************************************************************************************
  Min On & Min Off Signal
 * ************************************************************************************************
*/
bool sgMinTime::minTime(bool data,uint32_t minTimeOn,uint32_t minTimeOff) {
  
  if(OnOffStatusSaved) lastTimeOn = millis();
  if(!OnOffStatusSaved) lastTimeOff = millis();
  
  uint32_t curr = millis();
  if(curr < lastTimeOff) lastTimeOff =0;
  if(curr < lastTimeOn) lastTimeOn =0;
  
  bool overTimeOn = (curr - lastTimeOff) > minTimeOn;
  bool overTimeOff = (curr - lastTimeOn) > minTimeOff;

  if( ((!data) && (!OnOffStatusSaved)) || ((!data) && OnOffStatusSaved && overTimeOn) || (data && (!OnOffStatusSaved) && (!overTimeOff))) OnOffStatusSaved = false;  
  if( ((!data) && OnOffStatusSaved && (!overTimeOn)) || (data && OnOffStatusSaved) || (data && (!OnOffStatusSaved) && overTimeOff)) OnOffStatusSaved = true;
  
  return OnOffStatusSaved;
}

/*
 * ************************************************************************************************
  Clock Interval
 * ************************************************************************************************
*/
bool sgClock::sampleRate(uint32_t interval) {
  uint32_t curr = millis();
  if(curr < clockSaved) clockSaved =0;
  
  if((curr - clockSaved) > interval){
    clockSaved = millis();
    return true;
  } else {
    return false;
  }    
}

bool sgClock::pulse(uint32_t interval) {
  uint32_t curr = millis();
  if(curr < clockSaved) clockSaved =0;

  uint32_t interval_div2 = interval / 2;
  
  if((curr - clockSaved) > interval) clockSaved = millis();
  if((curr - clockSaved) <= interval_div2) return true;
  else return false;   
}

/*
 * ************************************************************************************************
  Run the actuator until end condition is on, delay check time and turn off actuator.
  After timeDelay change to next step
 * ************************************************************************************************
*/
bool stControl::Run()  {
  if(runCond) {
    if(timeDelay < mMinTime) timeDelay = mMinTime;    

    if(sgdMinTime.dON(stepChange,mMinTime)) {
      stepChange = false;
    }

    mCheckCond = (!stepChange) && checkCond;
    Out = !mCheckCond; 

   return sgdTimeDelay.dON(mCheckCond,timeDelay);
  }

  return  false;
}

/*
 * ************************************************************************************************
  Counter increase/ descrease
 * ************************************************************************************************
*/
      
int stCountIncDec::Run(bool condUp,bool condDown, int curData,int stepChange,int MinData, int MaxData) {

  int result;
  
  result = curData;

  if(condUp && condDown) return result;

  // First count
  if(sgeFirstUp.Rise(condUp)){
    result += stepChange;
  }

  if(sgeFirstDown.Rise(condDown)){
    result -= stepChange;
  }

  // Loop count
  if(sgdStartUp.dON(condUp,TIME_BASE))
  {
    if(sgcRateUp.sampleRate(TIME_RATE)) 
    {
      result += stepChange;
    }    
  }

  if(sgdStartDown.dON(condDown,TIME_BASE))
  {
    if(sgcRateDown.sampleRate(TIME_RATE)) 
    {
      result -= stepChange;
    }    
  }

  // Min and Max Check
  if(result > MaxData) result = MinData;
  if(result < MinData) result = MaxData;  

  return result;  

}

// result = 1 then increase, result = 2 then decrease
int stCountIncDec::Run(bool condUp,bool condDown) {
  int result;

  result = 0;
  if(condUp && condDown) return result;

  // First count
  if(sgeFirstUp.Rise(condUp)){
    result = 1;
  }

  if(sgeFirstDown.Rise(condDown)){
    result = 2;
  }

  // Loop count
  if(sgdStartUp.dON(condUp,TIME_BASE))
  {
    if(sgcRateUp.sampleRate(TIME_RATE)) 
    {
      result = 1;
    }    
  }

  if(sgdStartDown.dON(condDown,TIME_BASE))
  {
    if(sgcRateDown.sampleRate(TIME_RATE)) 
    {
      result = 2;
    }    
  }

  return result;
}


/*
 * ************************************************************************************************
  Filter
 * ************************************************************************************************
*/
      
uint16_t stFilter::Run(int16_t data,uint16_t sampNum) {
  
  sampCount++;
  sumData += data;
  if(sampCount == sampNum) {
    result = sumData/sampNum;
    sampCount = 0;
    sumData = 0;
  }
  return result;
}

/*********************************************************************************************************
** Class name:          System Control
** Descriptions:        Basic variable to control a system
** Input parameters:    None
** Output parameters:   None
** Returned value:      None
*********************************************************************************************************/ 

uint8_t stControlMode::get_RunMode(int pinModeChk) {
  if(sgeRunMode.Rise(digitalRead(pinModeChk))) {
    uint8_t result;
//    printf("RunMode: %d\r\n",mRunMode);
    if(mRunMode == manualMode) result = autoMode;
    if(mRunMode == autoMode) result = manualMode;
    mRunMode = result;
  }
}
