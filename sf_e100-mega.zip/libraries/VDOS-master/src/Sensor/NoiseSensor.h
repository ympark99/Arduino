/*
	소음 센서
	소음 수치를 표시하는데 사용하는 센서로 데이터는 실수 이다.
	데이터 타입: unsigned short
*/
#pragma once

#include "SensorClass.h"

class NoiseSensor : public SensorClass
{
	public:
		NoiseSensor() : SensorClass()
		{
			mSensorType = SENSOR_NOISE;
			mLength = sizeof(float);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(float data)
		{
			mData = data;
		} 
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		float mData;
};
