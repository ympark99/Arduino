/**
 * Created by Doan, Phuc Thinh on 2019-04-05.
 * Last Revision: 2019-04-05
 *
 * This library is used for system control, Automation
 *
 * Doan, Phuc Thinh (2019-04-05): Library start
 * sgEdge
 * sgDelay
 * sgMinTime
 * sgClock
 * stControl
 * stCountIncDec
 * stFilter
 * stControlMode
 * 
 * 
 */

#ifndef VITCON_CONTROL_H_
#define VITCON_CONTROL_H_

#include "Arduino.h"

namespace vitcon_ctr
{
  // sgEdge --------------------------------------------------------
  class sgEdge
  {
    public:
      sgEdge();
      bool Rise(bool data);
      bool Fall(bool data);
      bool RiseClose(bool data);
      bool FallClose(bool data);
    private:
      bool mRiseEdge;
      bool mFallEdge;
      bool mRiseCloseEdge;
      bool mFallCloseEdge;
  };

  // sgDelay --------------------------------------------------------
  class sgDelay
  {
    public:
      sgDelay();
      bool dON(bool data,uint32_t timedelay);
      bool dOFF(bool data,uint32_t timedelay);
    private:
      uint32_t mOnTime;
      bool mOffDelay;
      uint32_t mOffTime;
  };

  // sgMinTime -------------------------------------------------------
  class sgMinTime
  {
    public:
      sgMinTime();
      bool minTime(bool data,uint32_t minTimeOn,uint32_t minTimeOff);
    private:
      bool OnOffStatusSaved;
      uint32_t lastTimeOn;
      uint32_t lastTimeOff;
  };



  // sgClock ---------------------------------------------------------
  class sgClock
  {
    public:
      sgClock();
      bool sampleRate(uint32_t interval);
      bool pulse(uint32_t interval);
    private:
      uint32_t clockSaved;
  };

  // stControl ---------------------------------------------------------
  class stControl
  {
    public:      
      stControl();
      bool Run();
      uint16_t runStep;
      bool stepChange;
      bool runCond;
      bool checkCond;
      bool Out;    
      uint32_t timeDelay;    
    private:
      sgDelay sgdTimeDelay,sgdMinTime;
      static const uint32_t mMinTime = 10;
      bool mCheckCond;
  };

  // stCountIncDec  ------------------------------------------------------
  class stCountIncDec
  {
    public:
      static const uint32_t TIME_RATE = 100;
      static const uint32_t TIME_BASE  = 2000;
      stCountIncDec();
      int Run(bool condUp,bool condDown, int curData,int stepChange,int MinData, int MaxData);
      int Run(bool condUp,bool condDown);
    private:
      sgEdge sgeFirstUp;
      sgDelay sgdStartUp;
      sgClock sgcRateUp;
      sgEdge sgeFirstDown;
      sgDelay sgdStartDown;
      sgClock sgcRateDown;      
  };

  // stFilter  -----------------------------------------------------------
  class stFilter
  {
    public:
    stFilter();
    uint16_t Run(int16_t data,uint16_t sampNum);

    private:
    uint16_t sampCount;
    int32_t sumData;
    int16_t result;
    
  };

/*********************************************************************************************************
** Class name:          System Control
** Descriptions:        Basic variable to control a system
** Input parameters:    None
** Output parameters:   None
** Returned value:      None
*********************************************************************************************************/  
  class stControlMode
  {
    public:
    stControlMode();
    uint8_t get_RunMode(int pinModeChk);

    static const uint8_t manualMode = 0;
    static const uint8_t autoMode   = 1;

    private:
    uint8_t mRunMode;
    sgEdge sgeRunMode;
    
  };



  
}




#endif  /* VITCON_CONTROL_H_ */
