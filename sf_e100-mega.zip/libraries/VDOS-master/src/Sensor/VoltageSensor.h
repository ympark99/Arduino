/*
	전압 센서
	전압을 표시하는데 사용하는 센서로 데이터는 실수 이다.
	데이터 타입: float
*/
#pragma once

#include "SensorClass.h"

class VoltageSensor : public SensorClass
{
	public:
		VoltageSensor() : SensorClass()
		{
			mSensorType = SENSOR_VOLTAGE;
			mLength = sizeof(float);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(float data)
		{
			mData = data;
		} 
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		float mData;
};
