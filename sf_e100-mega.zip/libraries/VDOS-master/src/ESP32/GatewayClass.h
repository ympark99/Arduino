/*
	2020-03-10 jjh
	VDOS 게이트웨이 클래스
	게이트웨이 통신 및 게이트웨이를 위한 설정들을 담당한다.

	ESP32에서만 사용 가능함.
*/
#pragma once

#ifdef ESP32

#include <Arduino.h>
#include "SensorFactory.h"
#include "ActuatorFactory.h"
#include <vector>
#include <map>
#include <queue>
#include <mutex>


struct _staticip
{
  bool Enable; // 고정 ip 사용여부
  char IP[16]; //고정ip
  char Gateway[16]; //gateway ip
  char Subnet[16]; // subnet mask
  char DNS1[16]; // DNS 1
  char DNS2[16]; // DNS 2
};

struct _gateway
{
  bool Status; //작동상태. true or false
  uint16_t ReportInterval; //게이트웨이 데이터 전송주기. sec
	uint16_t MajorVersion; //현재 펌웨어의 major 버전
	uint16_t MinorVersion; //현재 펌웨어의 minor 버전
	uint16_t MaintainVersion; //현재 펌웨어의 maintain 버전
};

struct _wifi
{
  //타겟 wifi 설정
  bool Activate; //wifi 연결 사용여부. true시 연결 및 재연결 루틴 시작. false시 연결해제 및 재연결 루틴 중지.
  int AuthType; //wifi 암호화 타입
  char SSID[33]; //wifi ssid
  char Password[33]; //wifi 비번
  char UserID[65]; //기업형보안일떄 user id
  char UserPW[65]; //기업형보안일때 user password
  uint8_t MAC[6]; //wifi mac

  _staticip StaticIP;
};

struct _eth
{
  _staticip StaticIP;
	
	bool Connected = false; //연결 여부 확인용. pref에 저장되지 않는다.
};

extern _eth EthConfig;
extern _gateway GatewayConfig;
extern _wifi WifiConfig;


class GatewayClass
{
	public:
		GatewayClass(Stream*);
		void Init();
		void Run();

		//상태
		uint32_t GetLastCommTime(); //마지막 통신 후 지난 시간. 통신상태가 정상이라면 수집부에서 지속적으로 데이터를 보내 오므로 이 함수를 사용하면 수집장치가 정상인지 알 수 있다.

		//디바이스와의 통신
		void RequestSensorList(); //센서 리스트 요청을 보낸다.
		void RequestActuatorList(); //액추에이터 리스트 요청을 보낸다.
    void RequestActuatorRun(); //액추에이터 큐에 데이터가 있으면 액추에이터 실행 신호를 보낸다.

		//설정
		void ConfigLoad();
		void ConfigSave();
		void ConfigReset();

		void EthLoad();
		void EthSave();
		void WifiLoad();
		void WifiSave();
		void GatewayLoad();
		void GatewaySave();

		//Get
		const std::vector<SensorData>& GetSensorList() {return mNewSensorList;}
		const std::queue<SensorData>& GetEventQueue() { return mEventQueue;}
		const std::map<String, byte>& GetActuatorMap() { return mActuatorMap; }
		const std::vector<String>& GetActuatorList() { return mActuatorList; }

		const std::queue<ActuatorData>& GetActuatorResponseQueue() { return mActuatorResponseQueue;}

		//행동
		void ResetEvent(); //발생한 이벤트를 전부 삭제
    void EraseBeginEvent(); //가장 오래된 이벤트를 하나 지움
		int RunActuator(String name, String msgid, String params); //서버에서 보낸 액추에이터 실행 신호를 받아 디바이스에 보내기 위한 데이터를 생성함.
		void EraseBeginActuatorResponse(); //가장 오래된 액추에이터 응답 하나를 지움.

		bool ListChanged(); //센서 또는 액추에이터 리스트가 변경되었는지 여부.

		//네트워크 연결
		void EthConnect(); //설정한 정보대로 eth을 실행한다.
		void EthRefresh(); //eth 정보 변경시 적용시킨다.
		void WifiConnect(); //설정한 정보대로 wifi 연결을 시도한다.
		void WifiOn(); //wifi 기능을 켠다.
		void WifiOff(); //wifi 연결을 끊고 재접속 기능을 끈다.

	private:
		int mParsing();

    void mWifiCommand();
    void mEthCommand();
    void mGwInfoCommand();
    void mEtcCommand();

    void mResponse(byte cmd, const char* data, byte datalen);

    int mDataSize = 0;
    byte mData[255] = {0,};
    int mCmd = 0;

    Stream* mStream;
    int mCount = 0;

		//센서, 액추에이터 생산 공장
		SensorFactory mSensorFactory;
		ActuatorFactory mActuatorFactory;

		//센서, 액추에이터 기능
		void mSensorInit(byte* buf, int len);
		void mUpdateSensor(byte* buf, int len, bool event = false);

		void mActuatorInit(byte* buf, int len);
		void mActuatorResponse(byte* buf, int len);

		//void mAddSensorName(String);
		void mClearAll();

		void mClearSensor() { mSensorFactory.Clear(); mNewSensorList.clear(); }
		void mClearActuator() { mActuatorFactory.Clear(); mActuatorMap.clear(); mActuatorList.clear(); }

		std::vector<SensorData> mNewSensorList; //센서 리스트를 가지고 있는다.
		std::map<String, byte> mActuatorMap; //액추에이터 맵을 가지고 있는다.이름과 디바이스 인덱스..
		std::vector<String> mActuatorList; //액추에이터 이름 리스트를 가진다. 인덱스로 검색하기 위해..

		std::mutex mEventQueueLock;
		std::queue<SensorData> mEventQueue; //이벤트가 발생한 센서 데이터를 가지고 있는다. 수시로 add, clear되므로 mutex 처리

		std::mutex mActuatorRequestQueueLock;
		std::queue<ActuatorData> mActuatorRequestQueue; //실행할 액추에이터 정보를 가지고 있는다. 수시로 add, clear되므로 mutex처리
		std::mutex mActuatorResponseQueueLock;
		std::queue<ActuatorData> mActuatorResponseQueue; //액추에이터 응답 신호를 가지고 있는다. 수시로 add, clear되므로 mutex처리

		bool mListChange = false; 
		uint32_t mLastCommTime = 0;

		//const
    const static byte STX = 0x02;
    const static byte ETX = 0x03;

		const int WIFI_AUTHTYPE_OPEN = 0;
		const int WIFI_AUTHTYPE_ENCRYPT = 1;
		const int WIFI_AUTHTYPE_WPA2_ENTERPRISE = 2;

};

#else

#error GatewayClass is not available in AVR architecture.

#endif