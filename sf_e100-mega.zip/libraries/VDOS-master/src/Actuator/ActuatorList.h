#pragma once

const unsigned short ACTUATOR_COUNTRESET = 0x1000;
const unsigned short ACTUATOR_DIGITALWRITE = 0x1001;