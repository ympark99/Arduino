/*
	VDOS VDOS 수집장치 클래스
	
	2020-01-30 jjh

	2020-02-20 jjh 통신 프로토콜 v3 적용
	2020-03-06 jjh 통신 프로토콜 v4 적용중
	2020-03-10 jjh VDOS 수집장치 클래스로 명칭 변경
*/
#pragma once

#include <Arduino.h>
#include "Sensor/SensorClass.h"
#include "Actuator/ActuatorClass.h"

#define WIFI_OPEN 0
#define WIFI_WPA2 1
#define WIFI_ENTERPRISE 2

class DeviceClass
{
  public:
    DeviceClass(Stream* stream, SensorClass** sensors, byte sensorcount, ActuatorClass** actuators=NULL, byte actuatorcount = 0);
    void Init();
    bool Run();
		void SetInterval(uint16_t ms); //센서데이터 전송 주기 설정

		

		//데이터
    void SendSensorList();
		void SendActuatorList();
    void SendSeries(byte index);
    void SendSeriesAll();
    void SendEvent(byte index);

		//ESP32와의 통신 관련
		void SetResponseTimeout(uint16_t ms); //제어 응답 대기시 타임아웃 설정
		bool WaitForResponse(int cmd); //ESP32에 특정 커맨드 전송 후 응답 대기

		//Wifi 제어
		bool SetWifiSSID(String ssid, bool waitResponse = false); // 연결하려는 무선AP SSID 설정
		bool SetWifiEncrpyt(byte type, bool waitResponse = false); // 연결하려는 무선AP 암호화방식 설정
		bool SetWifiPassword(String password, bool waitResponse = false); //연결하려는 무선AP 암호 설정
		bool SetWifiEnterprise(String username, String password, bool waitResponse = false); //기업형보안 사용자이름 암호 설정
		bool SetWifiStatic(bool waitResponse); //고정 IP 사용.
		bool SetWifiDHCP(bool waitResponse = false); //DHCP를 사용.
		bool SetWifiIP(String ip, String subnet, String gateway, bool waitResponse = false); //고정IP 사용시 IP, subnet, gateway를 설정.
		bool SetWifiDNS(String dns1, String dns2, bool waitResponse = false); //고정IP 사용시 DNS 설정.
		bool WifiStart(bool waitResponse = false); //Wifi 연결.
		bool WifiStop(bool waitResponse = false); //Wifi 연결 끊기.
		bool GetWifiIP(char* ip, char* subnet, char* gateway); //Wifi의 할당받은 ip, subnet, gateway를 가져온다.

		//Ethernet 제어
		bool SetEthStatic(bool waitResponse = false); //고정IP를 사용.
		bool SetEthDHCP(bool waitResponse = false); //DHCP를 사용.
		bool SetEthIP(String ip, String subnet, String gateway, bool waitResponse = false); //고정IP 사용시 IP, subnet, gateway를 설정.
		bool SetEthDNS(String dns1, String dns2, bool waitResponse = false); //고정IP사용시 DNS설정
		bool GetEthIP(char* ip, char* subnet, char* gateway); //Ethernet의 할당받은 ip, subnet, gateway를 가져온다.
		bool EthRefresh(bool waitResponse = false); //Eth 변경사항을 적용시킨다.

		//게이트웨이 상태 제어
		bool GatewayStart(bool waitResponse = false); //게이트웨이 데이터전송 시작.
		bool GatewayStop(bool waitResponse = false); //게이트웨이 데이터전송 정지.
		bool SetGatewayReportInterval(uint16_t sec, bool waitResponse = false ); //게이트웨이 데이터전송주기 설정.

		//etc
		bool IsAlive(); //ESP32 응답하는지 확인
		bool GetDateTime(char* datetime); //로컬 타임 가져오기
		bool GetUnixTime(char* unixtime); //unix time 가져오기
		bool GetDeviceID(char* deviceid);



  private:
    void mSend(byte index, byte cmd);
    bool mParsing();
    int mRunActuator();
		void mSendActuatorResponse(byte index, char* msgid, uint16_t code);

    int mDataSize = 0;
    byte mData[256] = {0,};
    int mCmd;

    char mMsgID[10] = {0,};

    Stream* mStream;
    SensorClass** mSensor;
    byte mSensorCount = 0;
		ActuatorClass** mActuator;
		byte mActuatorCount = 0;

    uint32_t mInterval = 3000;
    uint32_t mSeriesTimer = 0;

		uint16_t mResponseTimeout = 500; //제어요청 응답대기시간 타임아웃

    const static byte STX = 0x02;
		const static byte ETX = 0x03;
};
