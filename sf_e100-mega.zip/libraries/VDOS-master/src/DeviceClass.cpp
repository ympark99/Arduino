#include "DeviceClass.h"
#include "CommCommand.h"
#include "ResponseCode.h"

#define DEBUG_MODE

#ifdef DEBUG_MODE
#define DEBUGPORT Serial
#else
#define DEBUGPORT while(0) Serial
#endif

DeviceClass::DeviceClass(Stream* stream, SensorClass** sensors, byte sensorcount, ActuatorClass** actuators, byte actuatorcount)
{
  mStream = stream;
  mSensor = sensors;
  mSensorCount = sensorcount;
	mActuator = actuators;
	mActuatorCount = actuatorcount;
  if ( mSensorCount > 127 ) mSensorCount = 127;
	if ( mActuatorCount > 127 ) mActuatorCount = 127;
}

void DeviceClass::Init()
{
  mStream->setTimeout(100);
}

void DeviceClass::SetInterval(uint16_t ms)
{
	if( ms < 100) ms  = 100;
	mInterval = ms;
}

bool DeviceClass::Run()
{
  if ( millis() - mSeriesTimer > mInterval )
  {
    mSeriesTimer = millis();
    SendSeriesAll();
  }

  if ( mParsing() )
  {
    if ( mCmd == CMD_SENSOR_LIST )
    {
      SendSensorList();
    }
    else if ( mCmd == CMD_SENSOR_SERIES )
    {
      SendSeries(mData[0]);
    }
    else if ( mCmd == CMD_SENSOR_EVENT )
    {
      //업음
    }
    else if ( mCmd == CMD_ACTUATOR_CONTROL )
    {
      mRunActuator();
    }
		else if ( mCmd == CMD_ACTUATOR_LIST )
		{
			SendActuatorList();
		}
		else 
		{
		}
  }

	//이벤트 센서 처리
  for (int i = 0; i < mSensorCount; i++)
  {
    if ( mSensor[i]->Changed() )
    {
      SendEvent(i);
      mSensor[i]->EventSended();
    }
  }
}

bool DeviceClass::mParsing()
{
  while ( mStream->available() )
  {
    byte stx, cmd, datalen, etx;
    mStream->readBytes((byte*)&stx, 1);
    //DEBUGPORT.print(String(stx) + " ");
    if ( stx != STX ) continue;
    mStream->readBytes((byte*)&cmd, 1);
    //DEBUGPORT.print(String(cmd) + " ");
    mStream->readBytes((byte*)&datalen, 1);
    //DEBUGPORT.print(String(datalen) + " ");
		memset(mData, 0, sizeof(mData));
    mStream->readBytes((byte*)mData, datalen);

    //for(int i=0;i<datalen;i++)
    //{
    //  DEBUGPORT.print(String(mData[i])+" ");
    //}
    //DEBUGPORT.println();

    mStream->readBytes((byte*)&etx, 1);
    //DEBUGPORT.println(String(etx) + " ");
    if ( etx != ETX ) continue;

    mDataSize = datalen;
    mCmd = cmd;

    return true;
  }
  return false;
}

int DeviceClass::mRunActuator()
{
	//액추에이터 제어 신호를 받으면 해당 액추에이터를 실행하고 게이트웨이에 응답을 보낸다.

	//액추에이터 제어 신호 DATA의 구성
	//index(1byte), msgid(36bytes), actuatordata(나머지)
	byte index;
	char msgid[37];
	memset(msgid, 0, sizeof(msgid));

	int datalen = mDataSize - 37;
	byte actuatordata[datalen];

	memcpy(&index, &mData[0], 1);
	memcpy(msgid, &mData[1], 36);
	memcpy(actuatordata, &mData[37], datalen);
/*
	DEBUGPORT.print("[RunActuator] index:");
	DEBUGPORT.print(index);
	DEBUGPORT.print(" msgid:");
	DEBUGPORT.print(msgid);
	DEBUGPORT.println();
*/
	uint16_t res = 0;

	if( index < mActuatorCount )
	{
		//액추에이터를 실행하고 결과에 따라 게이트웨이에 보낼 응답을 결정함.
		if( mActuator[index]->Activate(actuatordata) )
		{
			//성공시 응답
			 res= RESPONSE_SUCCESS;
		}
		else
		{
			//실패시 응답
			//여기서 실패하는 경우는 타임아웃인 경우밖에 없다고 가정함. 그 외의 경우는 Gateway에서 미리 처리하기 때문에 여기까지 안 온다.
			res= RESPONSE_TIMEOUT;
		}
	}
	else
	{
		//액추에이터 index over. 뭔가 잘못됨.
		res= RESPONSE_NOT_IMPLEMENTED;
	}

	mSendActuatorResponse(index, msgid, res);

	return res;
}

void DeviceClass::mSendActuatorResponse(byte index, char* msgid, uint16_t code)
{
	//액추에이터 응답 신호를 보낸다.

	//액추에이터 응답 신호 DATA의 구성
	//index(1byte), msgid(36bytes), response code(2byte)
	byte bufsize = 39;
	byte buf[bufsize];
	memcpy(&buf[0], &index, 1);
	memcpy(&buf[1], msgid, 36);
	memcpy(&buf[37], &code, 2);

	mStream->write(STX);
  mStream->write(CMD_ACTUATOR_CONTROL);
  mStream->write(bufsize);
  mStream->write(buf, bufsize);
  mStream->write(ETX);
}

void DeviceClass::SendSensorList()
{
  byte buf[mSensorCount * 2] = {0,};
  int bufsize = 0;

  for (int i = 0; i < mSensorCount; i++)
  {
    uint16_t type = mSensor[i]->GetType();
    memcpy(&buf[bufsize], &type, sizeof(uint16_t));
    //buf[bufsize] = lowByte(type);
    //buf[bufsize+1] = highByte(type);
    bufsize += 2;
  }
  mStream->write(STX);
  mStream->write(CMD_SENSOR_LIST);
  mStream->write(bufsize + 1);
  mStream->write(mSensorCount);
  mStream->write(buf, bufsize);
  mStream->write(ETX);
}

void DeviceClass::SendActuatorList()
{
  byte buf[mActuatorCount * 2] = {0,};
  int bufsize = 0;

  for (int i = 0; i < mActuatorCount; i++)
  {
    uint16_t type = mActuator[i]->GetType();
    memcpy(&buf[bufsize], &type, sizeof(uint16_t));
    bufsize += 2;
  }
  mStream->write(STX);
  mStream->write(CMD_ACTUATOR_LIST);
  mStream->write(bufsize + 1);
  mStream->write(mActuatorCount);
  mStream->write(buf, bufsize);
  mStream->write(ETX);
}


void DeviceClass::SendSeries(byte index)
{
  uint16_t type = mSensor[index]->GetType();
  int bufsize = mSensor[index]->GetLength();
  byte buf[bufsize];
  mSensor[index]->GetData(buf);

  mStream->write(STX);
  mStream->write(CMD_SENSOR_SERIES);
  mStream->write(bufsize + 3);
  mStream->write(index);
  mStream->write(lowByte(type));
  mStream->write(highByte(type));
  mStream->write(buf, bufsize);
  mStream->write(ETX);
}

void DeviceClass::SendSeriesAll()
{
  for (int i = 0; i < mSensorCount; i++)
  {
    SendSeries(i);
  }
}

void DeviceClass::SendEvent(byte index)
{
  uint16_t type = mSensor[index]->GetType();
  int bufsize = mSensor[index]->GetLength();
  byte buf[bufsize];
  mSensor[index]->GetData(buf);

  mStream->write(STX);
  mStream->write(CMD_SENSOR_EVENT);
  mStream->write(bufsize + 3);
  mStream->write(index);
  mStream->write(lowByte(type));
  mStream->write(highByte(type));
  mStream->write(buf, bufsize);
  mStream->write(ETX);
}

bool DeviceClass::WaitForResponse(int cmd)
{
		long timer = millis();
		while( millis() - timer < mResponseTimeout )
		{
			if ( mParsing() )
			{
				//DEBUGPORT.println(mCmd);
				/*
				if ( mCmd == CMD_WIFI_SSID )
				{
					String str = (char*)mData;
					if( str.equals("OK") ) return true;
					else return false;
				}
				else if( mCmd == CMD_ETH_GETIP )
				{
					return true;
				}
				*/
				if( mCmd == cmd ) return true;
			}
		}
		return false;
}

bool DeviceClass::SetWifiSSID(String ssid, bool waitResponse)
{
	int bufsize = ssid.length();
	byte buf[bufsize];
	
	byte cmd = CMD_WIFI_SSID;

	memcpy(buf, ssid.c_str(), bufsize);
	
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(bufsize);
	mStream->write(buf, bufsize);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetWifiEncrpyt(byte type, bool waitResponse)
{
	byte cmd = CMD_WIFI_AUTHTYPE;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x01);
	mStream->write(type);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetWifiPassword(String password, bool waitResponse)
{
	int bufsize = password.length();
	byte buf[bufsize];

	byte cmd = CMD_WIFI_PASSWORD;

	memcpy(buf, password.c_str(), bufsize);

	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(bufsize);
	mStream->write(buf, bufsize);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetWifiEnterprise(String username, String password, bool waitResponse)
{
	int bufsize = 128;
	byte buf[bufsize];
	byte cmd = CMD_WIFI_ENTERPRISE;

	memset(buf, 0, sizeof(buf));
	memcpy(&buf[0], username.c_str(), username.length());
	memcpy(&buf[64], password.c_str(), password.length());

	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(bufsize);
	mStream->write(buf, bufsize);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetWifiStatic(bool waitResponse)
{
	byte cmd = CMD_WIFI_STATICIP_USE;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x01);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetWifiDHCP(bool waitResponse)
{
	byte cmd = CMD_WIFI_STATICIP_USE;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x01);
	mStream->write((byte)0x01);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetWifiIP(String ip, String subnet, String gateway, bool waitResponse)
{
	int bufsize = 45;
	byte buf[bufsize];
	byte cmd = CMD_WIFI_STATICIP_DATA;

	memset(buf, 0, sizeof(buf));

	memcpy(&buf[0], ip.c_str(), ip.length());
	memcpy(&buf[15], subnet.c_str(), subnet.length());
	memcpy(&buf[30], gateway.c_str(), gateway.length());

	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(bufsize);
	mStream->write(buf, bufsize);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetWifiDNS(String dns1, String dns2, bool waitResponse)
{
	int bufsize = 30;
	byte buf[bufsize];
	byte cmd = CMD_WIFI_STATICIP_DNS;

	memset(buf, 0, sizeof(buf));

	memcpy(&buf[0], dns1.c_str(), dns1.length());
	memcpy(&buf[15], dns2.c_str(), dns2.length());

	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(bufsize);
	mStream->write(buf, bufsize);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::WifiStart(bool waitResponse)
{
	byte cmd = CMD_WIFI_START;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::WifiStop(bool waitResponse)
{
	byte cmd = CMD_WIFI_STOP;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::GetWifiIP(char* ip, char* subnet, char* gateway)
{
	int cmd = CMD_WIFI_GETIP;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	bool b = WaitForResponse(cmd);

	if( b) 
	{
		memcpy(ip, &mData[0], 15);
		memcpy(subnet, &mData[15], 15);
		memcpy(gateway, &mData[30], 15);
	}

	return b;
}

bool DeviceClass::SetEthStatic(bool waitResponse)
{
	byte cmd = CMD_ETH_STATICIP_USE;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x01);
	mStream->write((byte)0x01);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetEthDHCP(bool waitResponse)
{
	byte cmd = CMD_ETH_STATICIP_USE;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x01);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetEthIP(String ip, String subnet, String gateway, bool waitResponse)
{
	int bufsize = 45;
	byte buf[bufsize];
	byte cmd = CMD_ETH_STATICIP_DATA;

	memset(buf, 0, sizeof(buf));

	memcpy(&buf[0], ip.c_str(), ip.length());
	memcpy(&buf[15], subnet.c_str(), subnet.length());
	memcpy(&buf[30], gateway.c_str(), gateway.length());

	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(bufsize);
	mStream->write(buf, bufsize);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetEthDNS(String dns1, String dns2, bool waitResponse)
{
	int bufsize = 30;
	byte buf[bufsize];
	byte cmd = CMD_ETH_STATICIP_DNS;

	memset(buf, 0, sizeof(buf));

	memcpy(&buf[0], dns1.c_str(), dns1.length());
	memcpy(&buf[15], dns2.c_str(), dns2.length());

	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(bufsize);
	mStream->write(buf, bufsize);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::GetEthIP(char* ip, char* subnet, char* gateway)
{
	byte cmd = CMD_ETH_GETIP;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	bool b = WaitForResponse(cmd);

	if( b) 
	{
		memcpy(ip, &mData[0], 15);
		memcpy(subnet, &mData[15], 15);
		memcpy(gateway, &mData[30], 15);
	}

	return b;
}

bool DeviceClass::EthRefresh(bool waitResponse)
{
	byte cmd = CMD_ETH_REFRESH;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	if( waitResponse )
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::GatewayStart(bool waitResponse)
{
	byte cmd = CMD_GWINFO_ONOFF;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x01);
	mStream->write((byte)0x01);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::GatewayStop(bool waitResponse)
{
	byte cmd = CMD_GWINFO_ONOFF;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x01);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::SetGatewayReportInterval(uint16_t sec, bool waitResponse)
{
	byte cmd = CMD_GWINFO_REPORT_INTERVAL;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write(0x02);
	mStream->write((byte*)&sec, 2);
	mStream->write(ETX);

	if( waitResponse) 
	{
		if( WaitForResponse(cmd) )
		{
			String str = (char*)mData;
			if( str.equals("OK") ) return true;
			else return false;
		}
		else return false;
	}

	return true;
}

bool DeviceClass::IsAlive()
{
	byte cmd = CMD_ETC_HELLO;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	bool b = WaitForResponse(cmd);

	return b;
}

bool DeviceClass::GetDateTime(char* datetime)
{
	byte cmd = CMD_ETC_DATETIME;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	bool b = WaitForResponse(cmd);

	if( b )
	{
		memcpy(datetime, mData, 19);
	}

	return b;
}

bool DeviceClass::GetUnixTime(char* unixtime)
{
	byte cmd = CMD_ETC_UNIXTIME;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	bool b = WaitForResponse(cmd);

	if( b )
	{
		memcpy(unixtime, mData, 10);
	}

	return b;
}

bool DeviceClass::GetDeviceID(char* deviceid)
{
	byte cmd=  CMD_ETC_DEVICEID;
	mStream->write(STX);
	mStream->write(cmd);
	mStream->write((byte)0x00);
	mStream->write(ETX);

	bool b = WaitForResponse(cmd);

	if( b )
	{
		memcpy(deviceid, mData, 12);
	}

	return b;
}