#pragma once
#ifndef STOPWATCH_H
#define STOPWATCH_H

class StopWatch
{
protected:

    const int64_t UNAVAILABLE              = 0xFFFFFFFFFFFFFFFF;
    const int64_t UINT32_NUMERIC_LIMIT_MAX = 0x00000000FFFFFFFF;

public:

    virtual ~StopWatch() {}

    inline void start()
    {
        running = true;
        prev_us = micros();
        origin = now = (int64_t)prev_us;
        overflow = offset = 0;
    }
    inline void stop()
    {
        running = false;
        prev_us = 0;
        origin = now = UNAVAILABLE;
        overflow = offset = 0;
    }
    inline void play()
    {
        if (isPausing())
        {
            running = true;
            uint32_t curr_us = micros();
            if (curr_us > prev_us)
                origin += (int64_t)(curr_us - prev_us);
            else
                origin += UINT32_NUMERIC_LIMIT_MAX - (int64_t)(prev_us - curr_us);
            prev_us = curr_us;
        }
        else if (isRunning()) ;
        else                  start();
    }
    inline void pause()
    {
        if      (isRunning()) { microsec(); running = false; }
        else if (isPausing()) ;
        else                  stop();
    }
    inline void restart() { stop(); start(); }

    inline bool isRunning() const { return running; }
    inline bool isPausing() const { return (!running && (origin != UNAVAILABLE)); }

    inline double us() { return (double)microsec(); }
    inline double ms() { return us() * 0.001; }
    inline double sec() { return us() * 0.000001; }

    inline void offsetUs(double us) { offset = (int64_t)us; }
    inline void offsetMs(double ms) { offsetUs(1000. * ms); }
    inline void offsetSec(double sec) { offsetUs(1000000. * sec); }

protected:

    inline uint64_t microsec()
    {
        if      ( isPausing()) ;
        else if (!isRunning()) return 0;
        else
        {
            uint32_t curr_us = micros();
            if (curr_us < prev_us) overflow += UINT32_NUMERIC_LIMIT_MAX + (uint64_t)1;
            prev_us = curr_us;
            now = (uint64_t)curr_us + overflow;
        }
        return (uint64_t)(now - origin + offset);
    }

private:

    bool running {false};
    uint32_t prev_us {0};
    uint64_t origin {UNAVAILABLE};
    uint64_t now {UNAVAILABLE};
    uint64_t overflow {0};
    uint64_t offset {0};
};

#endif // STOPWATCH_H
