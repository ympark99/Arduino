#ifdef ESP32

#include "SensorFactory.h"
#include "../Sensors.h"
#include "../Util.h"

bool SensorFactory::MakeSensor(SensorData* sensor, uint16_t type)
{
	String name = "";
	String data = "";
	bool event = false;

	switch( type )
	{
		case SENSOR_NUMBER:
		{
			name = "number_f";
			data = "0.0";
			break;
		}
		case SENSOR_STRING:
		{
			name = "string_s";
			data = "\"\"";
			break;
		}
		case SENSOR_ONOFF:
		{
			name = "onoff_e";
			data = "0.0";
			event = true;
			break;
		}
		case SENSOR_TIME:
		{
			name = "time_i";
			data = "0";
			break;
		}
		case SENSOR_TEMPERATURE:
		{
			name = "temperature_f";
			data = "0.0";
			break;
		}
		case SENSOR_HUMIDITY:
		{
			name = "humidity_f";
			data = "0.0";
			break;
		}
		case SENSOR_METHAN:
		{
			name = "methan_i";
			data = "0";
			break;
		}
		case SENSOR_PERCENT:
		{
			name = "percent_f";
			data = "0.0";
			break;
		}
		case SENSOR_COUNT:
		{
			name = "count_i";
			data = "0";
			break;
		}
		case SENSOR_PULSE:
		{
			name = "pulse_e";
			data = "0.0";
			event = true;
			break;
		}
		case SENSOR_AMPERE:
		{
			name = "ampere_f";
			data = "0.0";
			break;
		}
		case SENSOR_VOLTAGE:
		{
			name = "voltage_f";
			data = "0.0";
			break;
		}
		case SENSOR_FREQUENCY:
		{
			name = "frequency_i";
			data = "0";
			break;
		}
		case SENSOR_ACTIVEPOWER:
		{
			name = "activepower_f";
			data = "0.0";
			break;
		}
		case SENSOR_REACTIVEPOWER:
		{
			name = "reactivepower_f";
			data = "0.0";
			break;
		}
		case SENSOR_APPARENTPOWER:
		{
			name = "apparentpower_f";
			data = "0.0";
			break;
		}
		case SENSOR_POWER:
		{
			name = "power_f";
			data = "0.0";
			break;
		}
		case SENSOR_POWERFACTOR:
		{
			name = "powerfactor_f";
			data = "0.0";
			break;
		}
		case SENSOR_BATTERY:
		{
			name = "battery_f";
			data = "0.0";
			break;
		}
		case SENSOR_THICKNESS:
		{
			name = "thickness_f";
			data ="0.0";
			break;
		}
		case SENSOR_WIDTH:
		{
			name = "width_f";
			data = "0.0";
			break;
		}
		case SENSOR_HEIGHT:
		{
			name = "height_f";
			data = "0.0";
			break;
		}
		case SENSOR_DISTANCE:
		{
			name = "distance_f";
			data = "0.0";
			break;
		}
		case SENSOR_WEIGHT:
		{
			name = "weight_f";
			data = "0.0";
			break;
		}
		case SENSOR_PRESSURE:
		{
			name = "pressure_f";
			data = "0.0";
			break;
		}
		case SENSOR_FLUX:
		{
			name = "flux_f";
			data = "0.0";
			break;
		}
		case SENSOR_PH:
		{
			name = "ph_f";
			data = "0.0";
			break;
		}
		case SENSOR_SPEED:
		{
			name = "speed_f";
			data = "0.0";
			break;
		}
		case SENSOR_ACCELERATION:
		{
			name = "acceleration_f";
			data = "0.0";
			break;
		}
		case SENSOR_CO2:
		{
			name = "co2_i";
			data = "0";
			break;
		}
		case SENSOR_CO:
		{
			name = "co_i";
			data = "0";
			break;
		}
		case SENSOR_DUST:
		{
			name = "dust_i";
			data = "0";
			break;
		}
		case SENSOR_NOISE:
		{
			name = "noise_f";
			data = "0.0";
			break;
		}
		case SENSOR_LIGHT:
		{
			name = "light_i";
			data = "0";
			break;
		}
		case SENSOR_LED:
		{
			name = "led_e";
			data = "0.0";
			break;
		}
		default:
			return false;
	}

	String jsonname = name + "-" + String(mSensorCount[name]);
	mSensorCount[name]++;
	sensor->name = jsonname;
	sensor->data = data;
	sensor->event = event;

	return true;
}

void SensorFactory::NewUpdateSensor(SensorData* sensor, byte* buf, int len)
{
	uint16_t sensortype;
	memcpy(&sensortype, &buf[1], sizeof(uint16_t));

	String data;

	//타입에 따른 데이터 파싱
	switch ( sensortype )
	{
		case SENSOR_NUMBER:
			{
				float num;
				memcpy(&num, &buf[3], sizeof(float));
				data = String(num, 1);
				break;
			}
		case SENSOR_STRING:
			{
				char c[len] = {0,};
				memcpy(c, &buf[3], len - 3);
				data = "\"" + String(c) + "\"";
				break;
			}
		case SENSOR_ONOFF:
			{
				byte value = buf[3];
				data = (value == 1 ? 1 : 0);
				break;
			}
		case SENSOR_LED:
			{
				byte value = buf[3];
				data = ( value == 1 ? 1 : 0 );
				break;
			}
		case SENSOR_TIME:
			{
				uint64_t num;
				memcpy(&num, &buf[3], sizeof(uint64_t));
				char temp[22] = {0,};
				sprintf(temp, "%llu", num);

				data = String(temp);
				break;
			}
		case SENSOR_HUMIDITY:
		case SENSOR_TEMPERATURE:
		case SENSOR_PERCENT:
		case SENSOR_AMPERE:
		case SENSOR_VOLTAGE:
		case SENSOR_ACTIVEPOWER:
		case SENSOR_REACTIVEPOWER:
		case SENSOR_APPARENTPOWER:
		case SENSOR_POWER:
		case SENSOR_POWERFACTOR:
		case SENSOR_BATTERY:
		case SENSOR_THICKNESS:
		case SENSOR_WIDTH:
		case SENSOR_HEIGHT:
		case SENSOR_DISTANCE:
		case SENSOR_WEIGHT:
		case SENSOR_PRESSURE:
		case SENSOR_FLUX:
		case SENSOR_PH:
		case SENSOR_SPEED:
		case SENSOR_ACCELERATION:
		case SENSOR_NOISE:
			{
				float num;
				memcpy(&num, &buf[3], sizeof(float));
				data = String(num, 1);
				break;
			}
		case SENSOR_METHAN:
		case SENSOR_CO2:
		case SENSOR_CO:
		case SENSOR_DUST:
			{
				uint16_t num;
				memcpy(&num, &buf[3], sizeof(uint16_t));
				data = String(num);
				break;
			}
		case SENSOR_COUNT:
		case SENSOR_FREQUENCY:
		case SENSOR_LIGHT:
			{
				uint32_t num;
				memcpy(&num, &buf[3], sizeof(uint32_t));
				data = String(num);
				break;
			}
		case SENSOR_PULSE:
			{
				byte value = buf[3];
				data = ( value == 1 ? 1 : 0 );
				break;
			}
		default:
		{
			return;
			break;
		}
	}

	sensor->data = data;
	sensor->time = GetTimestamp();
}


#endif