/*
	카운트리셋 액추에이터
	어떤 수치를 카운트 하는 기능이 있을 경우 해당 카운트 값을 초기화 하기 위해 호출하는 액추에이터.

	cmd: "reset"
	params: 없음
	callback함수 형태: void func(bool*)
*/
#pragma once

#include "ActuatorClass.h"

class CountResetActuator : public ActuatorClass
{
	public:
		CountResetActuator(bool (*func)()) : ActuatorClass()
		{
			mFunc = func;
			mActuatorType = ACTUATOR_COUNTRESET;
		}

		virtual bool Activate(byte* buf)
		{
			//커맨드가 하나이므로 별도의 처리 없이 callback 호출 하면 된다.
			bool b = mFunc();
			
			return b;
		}

	private:
		//콜백함수
		//반환값: 처리 결과
		bool (* mFunc)(); 
		 
};