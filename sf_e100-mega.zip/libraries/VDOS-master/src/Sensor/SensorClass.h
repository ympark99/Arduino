/*
    센서 추상 클래스
	2020-01-30 jjh
*/

#pragma once

#include <Arduino.h>

#include "SensorList.h"


#define DEBUGPORT Serial

class SensorClass
{
	public:
		SensorClass()
		{
			mIsEvent = false;
		}
		unsigned short GetType()
		{
			return mSensorType;
		}
		unsigned short GetLength()
		{
			return mLength;
		}
		bool Event()
		{
			return mIsEvent;
		}
		virtual void PrintData()		{		}
		virtual unsigned short GetData(unsigned char* buf) {return 0;}
		virtual bool Changed() { return false;}
		virtual void EventSended() { }

	protected:
		unsigned short mSensorType;
		unsigned short mLength;
		unsigned short mIsEvent;
};
