#pragma once

#ifdef ESP32
#include <map>
#include <Arduino.h>

struct ActuatorData
{
	String name; //JSON에 사용하는 액추에이터 이름
	String msgid; //JSON에 사용하는 메시지 ID
	String params; //JSON에 사용하는 params
	uint16_t code; //응답코드
};

class ActuatorFactory
{
	public:
		ActuatorFactory() {}

		bool NewMakeActuator(String* name, uint16_t type); //리스트에 넣을 새로운 액추에이터를 만든다. 리스트에 넣을 액추에이터는 이름만 있어도 되지 않을까.. 하는 생각
		int ActuatorGetDeviceData(ActuatorData actuator, byte* buf); //서버->게이트웨이 의 액추에이터 호출 정보를 바탕으로 게이트웨이->디바이스 에 사용할 데이터를 생성 한다.
		bool ActuatorGetGatewayData(byte* buf, ActuatorData* actuator); //디바이스->게이트웨이 의 액추에이터 응답 정보를 게이트웨이->서버 로 인터페이싱 한다.

		void Clear() //액추에이터 생성 수량을 초기화한다.
		{
			mActuatorCount.clear();
		}

		void JsonTest();

	private:
		std::map<String, int> mActuatorCount; //생성한 액추에이터 개수를 가지고 있는다.

		unsigned short mGetActuatorType(String name); //액추에이터 이름으로 타입을 알아낸다.


};


#endif