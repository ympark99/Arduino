#ifndef _REMOTEDATA_H
#define _REMOTEDATA_H

#include <stdint.h>

/*********************************************************************************************************
** Data structure
*********************************************************************************************************/
#pragma pack(push)
#pragma pack(1)

/*********************************************************************************************************
** Slave1 : Submodlink (Loading)
*********************************************************************************************************/

typedef struct tagBitDataSlave1 {
  // Loading Status
  bool loadAllHome;                       // Index 00~03
  bool loadRun;
  bool loadError;
  bool loadReady;  

  // 4Axis Robot status
  bool homeUpOk;                          // Index 04~09
  bool homeDnOk;
  bool loadUpOk;
  bool loadDnOk;
  bool unloadUpOk;
  bool unloadDnOk;

  // Input Signals
  bool In00; //BAT LOAD IN CHECK          // Index 10~14
  bool In01; //BAT LOAD OUT CHECK
  bool In02; //BAT BARCODE CHECK
  bool In03; //BAT READY POS CHECK
  bool In04; //LOAD VACUUM CHECK

  // Output Signals
  bool Out10; //LOAD CONV MOTOR          // Index 15~16
  bool Out11; //LOAD VACUUM

  // Start, Stop Signals                       // Index 17~18
  bool loadRunStart;
  bool loadSignal;

  // Vitcon Server Manual
  bool cmdMotorOFF;                      // Index 18~31
  bool cmdMotorON;
  bool cmdVacuumOFF;
  bool cmdVacuumON;
  bool cmdBarcodeRead;
  bool cmdHomeUp;
  bool cmdHomeDn;
  bool cmdLoadUp;
  bool cmdLoadDn;
  bool cmdUnloadUp;
  bool cmdUnloadDn;
  bool cmdCycleRun;
  bool cmdCounterReset; 

  // Loading Run Condition
  bool batReturnReady;                  // Index 32

} BitDataSlave1;

typedef struct tagWordDataSlave1 {
  uint32_t loadCycleTime;               // Index 00~15
  uint32_t loadCountOK;
  uint32_t loadCountNG;
  uint16_t curBarcode[10];
  uint16_t spared[2];
} WordDataSlave1;

/*********************************************************************************************************
** Slave2 : PLC1-Mitsu (Shuttle)
*********************************************************************************************************/

typedef struct tagBitDataSlave2 {
  // Shuttle Status
  bool ShuttleAllHome;                  // Index 00~05
  bool ShuttleRun;
  bool ShuttleError;
  bool ShuttleLoadDnIntlk;
  bool ShuttleUnloadDnIntlk;
  bool  MeasureRequest;

  
  // Input Signals
  bool  InputThickChk;                  // Index 06~14
  bool InputVacuumChk1;
  bool InputVacuumChk2;
  bool InputVacuumChk3;
  bool InputVacuumChk4;
  bool InputMainPickerUp;
  bool InputMainPickerDn;
  bool InputSubPickerUp;
  bool InputSubPickerDn;

  // Output Signals
  bool OutputVacuum1;                 // Index 15~22
  bool OutputVacuum2;
  bool OutputVacuum3;
  bool OutputVacuum4;
  bool OutputMainPickerUp;
  bool OutputMainPickerDn;
  bool OutputSubPickerUp;
  bool OutputSubPickerDn; 
  
  //  Start,Stop Signals                  // Index 23~24
  bool ShuttleRunStart;
  bool ShuttleSignal;

  // Input Signals from Measurement
  bool InputAlign1GageXBwd;               // Index 25~40
  bool InputAlign1GageXFwd;
  bool InputAlign2VoltageBwd;
  bool InputAlign2VoltageFwd;
  bool InputAlign3GageYBwd;
  bool InputAlign3GageYFwd;
  bool InputGageXChk;
  bool InputVoltageChk;
  bool InputGageYChk;
  bool InputBatStage1Chk;
  bool InputBatStage2Chk;
  bool InputBatStage3Chk;       // input signal from Unloading
  bool InputBatUnloadChk;    // input signal from Unloading
  bool UnloadConvMotorRun;     // input signal from Unloading
 
  bool InputBatLoadChk;       // input signal from Loading

  // Loading Run Condition
  bool loadReady;             // input signal from Loading

  // Vitcon Server Manual
  bool cmdVacuum1OFF;                 // Index 41~57
  bool cmdVacuum1ON;
  bool cmdVacuum2OFF;
  bool cmdVacuum2ON;
  bool cmdVacuum3OFF;
  bool cmdVacuum3ON;
  bool cmdVacuum4OFF;
  bool cmdVacuum4ON;
  bool cmdMainPickerUp;
  bool cmdMainPickerDn;
  bool cmdSubPickerUp;
  bool cmdSubPickerDn;
  bool cmdServoLoadMov;
  bool cmdServoNGMov;
  bool cmdServoUnloadMov;
  bool cmdServoJogFwd;
  bool cmdServoJogBwd;

} BitDataSlave2;

typedef struct tagWordDataSlave2 {

  uint32_t shuttleCycleTime;               // Index 00~16
  uint32_t shuttleCount;
  uint32_t shuttleCountOK;
  uint32_t shuttleCountNG;
  uint32_t shuttlePercentCountOK;
  uint32_t shuttlePercentCountNG;
  uint32_t shuttleCountNGz;
  uint16_t testResult1;
  uint16_t testResult2;
  uint16_t testResult3;
  uint16_t Barcode1[10];                  // Index 17~76
  uint16_t Barcode2[10];
  uint16_t Barcode3[10];
  uint16_t Barcode4[10];
  uint16_t Barcode5[10];
  uint16_t endBarcode[10];
  uint16_t curBarcode[10];                // Index 77~86

} WordDataSlave2;

/*********************************************************************************************************
** Slave3 : PLC2-Mitsu (Measurement)
*********************************************************************************************************/

typedef struct tagBitDataSlave3 {
  // Measurement Status
  bool MeasureSignal;                  // Index 00~02
  bool MeasureRun;
  bool MeasureError;

  // Input Signals
  bool InputAlign1GageXBwd;             // Index 03~13
  bool InputAlign1GageXFwd;
  bool InputAlign2VoltageBwd;
  bool InputAlign2VoltageFwd;
  bool InputAlign3GageYBwd;
  bool InputAlign3GageYFwd;
  bool InputGageXChk;
  bool InputVoltageChk;
  bool InputGageYChk;
  bool InputBatStage1Chk;
  bool InputBatStage2Chk;

  // Output Signals
  bool OutputAlign1GageXFwd;             // Index 14~16
  bool OutputAlign2VoltageFwd;
  bool OutputAlign3GageYFwd;

  // Vitcon Server Manual
  bool cmdGageXBwd;                     // Index 17~23
  bool cmdGageXFwd;
  bool cmdVoltageBwd;
  bool cmdVoltageFwd;
  bool cmdGageYBwd;
  bool cmdGageYFwd;
  bool MeasureRequest;
} BitDataSlave3;

typedef struct tagWordDataSlave3 {
  uint32_t measureCycleTime;               // Index 00~09
  uint32_t measureCount;
  uint32_t measureCountOK;
  uint32_t measureCountXNG;
  uint32_t measureCountYNG;
  uint32_t measureCounVoltNG;
} WordDataSlave3;

/*********************************************************************************************************
** Slave4 : PLC1-LS (Unloading)
*********************************************************************************************************/

typedef struct tagBitDataSlave4 {
  // Unloading Status
  bool unloadAllHome;                 // Index 00~02
  bool unloadRun;
  bool unloadError;
  
  // Input Signals
  bool InputPickerUp;                 // Index 03~10
  bool InputPickerDn;
  bool InputPickerBwd;
  bool InputPickerFwd;
  bool InputVacuumChk;
  bool InputBatUnloadChk;
  bool InputBatUnloadOutChk;
  bool InputBatStage3Chk;

  // Output Signals
  bool OutputPickerUp;                 // Index 11~16
  bool OutputPickerDn;
  bool OutputPickerBwd;
  bool OutputPickerFwd;
  bool OutputConvMotorRun;
  bool OutputVacuumOn;

  // Start,Stop Signals               // Index 17~18
  bool unloadRunStart;
  bool UnloadSignal;

  // Vitcon Server Manual
  bool cmdPickerUp;                 // Index 18~26
  bool cmdPickerDn;
  bool cmdPickerBwd;
  bool cmdPickerFwd;
  bool cmdVacuumOff;
  bool cmdVacuumOn;
  bool cmdConvMotorOff;
  bool cmdConvMotorOn;

  // Interlock for conveyor motor
  bool ShuttleUnloadDnIntlk;                 // Index 27~28
  bool ReturnBatInChk;
  
} BitDataSlave4;

typedef struct tagWordDataSlave4 {
  uint32_t unloadCycleTime;               // Index 00~03
  uint32_t unloadCount;
} WordDataSlave4;

/*********************************************************************************************************
** Slave5 : PLC2-LS (Return)
*********************************************************************************************************/

typedef struct tagBitDataSlave5 {
  // Return Status
  bool ReturnAllHome;                 // Index 00~03
  bool ReturnRun;
  bool ReturnError;
  bool batReturnReady;

  // Input Signals
  bool InputBatInChk;                 // Index 04~07
  bool InputBatLowSpdChk;
  bool InputBatOut1Chk;
  bool InputBatOut2Chk;
  
  // Output Signals
  bool OutputConvMotorRun;                 // Index 08~11
  bool OutputConvSpdLow;
  bool OutputConvSpdMedium;
  bool OutputConvSpdHigh;

  // Start,Stop Signals                        // Index 12~14
  bool ReturnRunStart;
  bool ReturnRunStop;

  // Vitcon Server Manual
  bool cmdConvMotorOff;                 // Index 14~18
  bool cmdConvMotorOn;
  bool cmdConvSpdLow;
  bool cmdConvSpdMedium;
  bool cmdConvSpdHigh;
} BitDataSlave5;

typedef struct tagWordDataSlave5 {
  uint32_t ReturnCycleTime;
  uint32_t ReturnCount;
} WordDataSlave5;

/*********************************************************************************************************
** Full Data
*********************************************************************************************************/

typedef struct tagFullDataSlave {
  BitDataSlave1 bit1;
  BitDataSlave2 bit2;
  BitDataSlave3 bit3;
  BitDataSlave4 bit4;
  BitDataSlave5 bit5;
  WordDataSlave1 Word1;
  WordDataSlave2 Word2;
  WordDataSlave3 Word3;
  WordDataSlave4 Word4;
  WordDataSlave5 Word5;
}FullDataSlave;

extern FullDataSlave rData;

/*********************************************************************************************************
** End
*********************************************************************************************************/
#pragma pack(pop)

#endif
