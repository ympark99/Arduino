/*
	카운터 센서
	갯수를 세는데 사용하는 센서로 데이터는 0 또는 양의 정수 이다.
	데이터 타입: unsigned long
*/
#pragma once

#include "SensorClass.h"

class CountSensor : public SensorClass
{
	public:
		CountSensor() : SensorClass()
		{
			mSensorType = SENSOR_COUNT;
			mLength = sizeof(unsigned long);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(unsigned long data)
		{
			mData = data;
		} 
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		unsigned long mData;
};
