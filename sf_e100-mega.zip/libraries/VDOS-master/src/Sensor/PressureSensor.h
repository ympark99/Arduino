/*
	압력 센서
	압력 수치를 표시하는데 사용하는 센서로 데이터는 실수 이다.
	데이터 타입: float
*/
#pragma once

#include "SensorClass.h"

class PressureSensor : public SensorClass
{
	public:
		PressureSensor() : SensorClass()
		{
			mSensorType = SENSOR_PRESSURE;
			mLength = sizeof(float);
			mData = 0;
		}
		virtual unsigned short GetData(unsigned char* buf)
		{
			memcpy(buf, &mData, mLength);

			return mLength;
		}
		virtual void SetData(float data)
		{
			mData = data;
		} 
		virtual void PrintData()
		{
			DEBUGPORT.println(mData);
		}


	private:
		float mData;
};
