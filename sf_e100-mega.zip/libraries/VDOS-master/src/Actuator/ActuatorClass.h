/*
	2020-02-26 jjh
	액추에이터 추상 클래스
*/
#pragma once

#include <Arduino.h>
#include "ActuatorList.h"

class ActuatorClass
{
	public:
		ActuatorClass()
		{

		}
		unsigned short GetType()
		{
			return mActuatorType;
		}

		virtual bool Activate(byte* buf) {}


	protected:
		unsigned short mActuatorType;
};