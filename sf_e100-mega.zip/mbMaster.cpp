/*
 * modbus.h  
 *  Discrete Coils/Flags
 *  0x01 - Read Coils
 *  0x02 - Read Discrete Inputs
 *  0x05 - Write Single Coil
 *  0x0F - Write Multiple Coils
 *  
 *  Registers
 *  0x03 - Read Holding Registers
 *  0x04 - Read Input Registers
 *  0x06 - Write Single Register
 *  0x10 - Write Multiple Registers
 *  0x16 - Mask Write Register
 *  0x17 - Read Write Multiple Registers
*/

#include "mbMaster.h"

mbMaster mbMaster1;

mbMaster::mbMaster() {}


/*******************************************************************************************
 * Init
*******************************************************************************************/

void mbMaster::init() {
  Master1.begin(ID_AS_SLAVE1,Serial3);
  Master2.begin(ID_AS_SLAVE2,Serial2);
  Master3.begin(ID_AS_SLAVE3,Serial2);
  Master4.begin(ID_AS_SLAVE4,Serial2);
  Master5.begin(ID_AS_SLAVE5,Serial2);
  
}

/*******************************************************************************************
 * Run
*******************************************************************************************/

void mbMaster::run() {

  uint32_t startTime = millis();
  uint32_t endTime;
  remoteDataUpdate();
  ProcessSlave1();
  ProcessSlave2();
  delay(10);
  ProcessSlave3();
  delay(10);
  ProcessSlave4();
  delay(10);
  ProcessSlave5();
  delay(10);
  
  endTime = millis() - startTime;  
//  Serial.println("slave5: " + String(endTime));
}

/*******************************************************************************************
 * Remote Data Update
*******************************************************************************************/
void mbMaster::remoteDataUpdate() {

  // Slave1- Loading
  rData.bit1.batReturnReady = rData.bit5.batReturnReady;

  // Slave2- PLC1-Mitsu
  rData.bit2.InputAlign1GageXBwd = rData.bit3.InputAlign1GageXBwd;
  rData.bit2.InputAlign1GageXFwd = rData.bit3.InputAlign1GageXFwd;
  rData.bit2.InputAlign2VoltageBwd = rData.bit3.InputAlign2VoltageBwd;
  rData.bit2.InputAlign2VoltageFwd = rData.bit3.InputAlign2VoltageFwd;
  rData.bit2.InputAlign3GageYBwd = rData.bit3.InputAlign3GageYBwd;
  rData.bit2.InputAlign3GageYFwd = rData.bit3.InputAlign3GageYFwd;  
  rData.bit2.InputGageXChk = rData.bit3.InputGageXChk;
  rData.bit2.InputVoltageChk = rData.bit3.InputVoltageChk;
  rData.bit2.InputGageYChk = rData.bit3.InputGageYChk;

  rData.bit2.InputBatStage1Chk = rData.bit3.InputBatStage1Chk;
  rData.bit2.InputBatStage2Chk = rData.bit3.InputBatStage2Chk;

  rData.bit2.InputBatStage3Chk = rData.bit4.InputBatStage3Chk;
  rData.bit2.InputBatUnloadChk = rData.bit4.InputBatUnloadChk;
  rData.bit2.UnloadConvMotorRun = rData.bit4.OutputConvMotorRun;
    
  rData.bit2.InputBatLoadChk = rData.bit1.In03;
  rData.bit2.loadReady = rData.bit1.loadReady;   

  memcpy(rData.Word2.curBarcode,rData.Word1.curBarcode,8);

  // Slave3- PLC2-Mitsu
  rData.bit3.MeasureRequest = rData.bit2.MeasureRequest;

  // Slave4- PLC1-LS
  rData.bit4.ShuttleUnloadDnIntlk = rData.bit2.ShuttleUnloadDnIntlk;
  rData.bit4.ReturnBatInChk = rData.bit5.InputBatInChk;
  

  // Slave5- PLC2-LS
  

  
    

}

/*******************************************************************************************
 * Slave1
*******************************************************************************************/
void mbMaster::ProcessSlave1() {

  // Read Bit Data 
  const uint8_t rbAdr =0;
  const uint8_t rbSize =BIT_SLAVE1_READSIZE;
  bool rbdata[rbSize];   

  if(Master1.readCoils(BIT_SLAVE1_ADDRESS + rbAdr,rbSize) == Master1.ku8MBSuccess) {    
  for(int i = 0; i < rbSize; i++) {
    uint8_t index = i/16;
    rbdata[i] = bitRead(Master1.getResponseBuffer(index),i%16);
  }
  memcpy(&rData.bit1,rbdata,rbSize);   
  }

  // Wrtie Bit Data
  const uint8_t wbAdr =rbSize;
  const uint8_t wbSize =sizeof(rData.bit1)-rbSize;
  uint16_t wbWSize = wbSize/16 +1;
  bool wbdata[wbSize];
  uint16_t wbWdata[wbWSize];
  
  memcpy(wbdata,(uint16_t)&rData.bit1 + wbAdr,wbSize);
  for(int i = 0; i < wbSize; i++) {
    uint8_t index1 = i/16;
    uint8_t index2 =  i%16;    
    bitWrite(wbWdata[index1],index2,wbdata[i]);
  }
  for(int i = 0; i < wbWSize; i++) {
    Master1.setTransmitBuffer(i,wbWdata[i]);
  }
  Master1.writeMultipleCoils(BIT_SLAVE1_ADDRESS + wbAdr,wbSize);

  // Read Word Data
  const uint8_t rwAdr =0;
  const uint8_t rwSize = DATA_SLAVE1_READSIZE;
  uint16_t rwdata[rwSize];

  if(Master1.readHoldingRegisters(DATA_SLAVE1_ADDRESS + rwAdr,rwSize) == Master1.ku8MBSuccess) {    
    for(int i = 0; i < rwSize; i++) {
      rwdata[i] = Master1.getResponseBuffer(i);
    }
    memcpy(&rData.Word1,rwdata,rwSize*2);    
  }

  // Write Word Data
  const uint8_t wwAdr =rwSize;
  const uint8_t wwSize =sizeof(rData.Word1)/2-rwSize;
  uint16_t wwdata[wwSize];

  memcpy(wwdata,(uint16_t)&rData.Word1 + wwAdr*2,wwSize*2);
  for(int i = 0; i < wwSize; i++) {
    Master1.setTransmitBuffer(i,wwdata[i]);
  }
  Master1.writeMultipleRegisters(DATA_SLAVE1_ADDRESS + wwAdr,wwSize);
}

/*******************************************************************************************
 * Slave2
*******************************************************************************************/
void mbMaster::ProcessSlave2() {

  // Read Bit Data 
  const uint8_t rbAdr =0;
  const uint8_t rbSize =BIT_SLAVE2_READSIZE;
  bool rbdata[rbSize];   

  if(Master2.readCoils(BIT_SLAVE2_ADDRESS + rbAdr,rbSize) == Master2.ku8MBSuccess) {    
  for(int i = 0; i < rbSize; i++) {
    uint8_t index = i/16;
    rbdata[i] = bitRead(Master2.getResponseBuffer(index),i%16);
  }
  memcpy(&rData.bit2,rbdata,rbSize);   
  }

  // Wrtie Bit Data
  const uint8_t wbAdr =rbSize;
  const uint8_t wbSize =sizeof(rData.bit2)-rbSize;
  uint16_t wbWSize = wbSize/16 +1;
  bool wbdata[wbSize];
  uint16_t wbWdata[wbWSize];
  
  memcpy(wbdata,(uint16_t)&rData.bit2 + wbAdr,wbSize);
  for(int i = 0; i < wbSize; i++) {
    uint8_t index1 = i/16;
    uint8_t index2 =  i%16;    
    bitWrite(wbWdata[index1],index2,wbdata[i]);
  }
  for(int i = 0; i < wbWSize; i++) {
    Master2.setTransmitBuffer(i,wbWdata[i]);
  }
  Master2.writeMultipleCoils(BIT_SLAVE2_ADDRESS + wbAdr,wbSize);

  // Read Word Data
  const uint8_t rwAdr =0;
  const uint8_t rwSize = DATA_SLAVE2_READSIZE;
  uint16_t rwdata[rwSize];

  if(Master2.readHoldingRegisters(DATA_SLAVE2_ADDRESS + rwAdr,rwSize) == Master2.ku8MBSuccess) {    
    for(int i = 0; i < rwSize; i++) {
      rwdata[i] = Master2.getResponseBuffer(i);
    }
    memcpy(&rData.Word2,rwdata,rwSize*2);    
  }

  // Write Word Data
  const uint8_t wwAdr =rwSize;
  const uint8_t wwSize =sizeof(rData.Word2)/2-rwSize;
  uint16_t wwdata[wwSize];

  memcpy(wwdata,(uint16_t)&rData.Word2 + wwAdr*2,wwSize*2);
  for(int i = 0; i < wwSize; i++) {
    Master2.setTransmitBuffer(i,wwdata[i]);
  }
  Master2.writeMultipleRegisters(DATA_SLAVE2_ADDRESS + wwAdr,wwSize);
}

/*******************************************************************************************
 * Slave3
*******************************************************************************************/
void mbMaster::ProcessSlave3() {

  // Read Bit Data 
  const uint8_t rbAdr =0;
  const uint8_t rbSize =BIT_SLAVE3_READSIZE;
  bool rbdata[rbSize];   

  if(Master3.readCoils(BIT_SLAVE3_ADDRESS + rbAdr,rbSize) == Master3.ku8MBSuccess) {    
  for(int i = 0; i < rbSize; i++) {
    uint8_t index = i/16;
    rbdata[i] = bitRead(Master3.getResponseBuffer(index),i%16);
  }
  memcpy(&rData.bit3,rbdata,rbSize);   
  }

  // Wrtie Bit Data
  const uint8_t wbAdr =rbSize;
  const uint8_t wbSize =sizeof(rData.bit3)-rbSize;
  uint16_t wbWSize = wbSize/16 +1;
  bool wbdata[wbSize];
  uint16_t wbWdata[wbWSize];
  
  memcpy(wbdata,(uint16_t)&rData.bit3 + wbAdr,wbSize);
  for(int i = 0; i < wbSize; i++) {
    uint8_t index1 = i/16;
    uint8_t index2 =  i%16;    
    bitWrite(wbWdata[index1],index2,wbdata[i]);
  }
  for(int i = 0; i < wbWSize; i++) {
    Master3.setTransmitBuffer(i,wbWdata[i]);
  }
  Master3.writeMultipleCoils(BIT_SLAVE3_ADDRESS + wbAdr,wbSize);

  // Read Word Data
  const uint8_t rwAdr =0;
  const uint8_t rwSize = DATA_SLAVE3_READSIZE;
  uint16_t rwdata[rwSize];

  if(Master3.readHoldingRegisters(DATA_SLAVE3_ADDRESS + rwAdr,rwSize) == Master3.ku8MBSuccess) {    
    for(int i = 0; i < rwSize; i++) {
      rwdata[i] = Master3.getResponseBuffer(i);
    }
    memcpy(&rData.Word3,rwdata,rwSize*2);    
  }

  // Write Word Data
  const uint8_t wwAdr =rwSize;
  const uint8_t wwSize =sizeof(rData.Word3)/2-rwSize;
  uint16_t wwdata[wwSize];

  memcpy(wwdata,(uint16_t)&rData.Word3 + wwAdr*2,wwSize*2);
  for(int i = 0; i < wwSize; i++) {
    Master3.setTransmitBuffer(i,wwdata[i]);
  }
  Master3.writeMultipleRegisters(DATA_SLAVE3_ADDRESS + wwAdr,wwSize);
}

/*******************************************************************************************
 * Slave4
*******************************************************************************************/
void mbMaster::ProcessSlave4() {

  // Read Bit Data 
  const uint8_t rbAdr =0;
  const uint8_t rbSize =BIT_SLAVE4_READSIZE;
  bool rbdata[rbSize];   

  if(Master4.readCoils(BIT_SLAVE4_ADDRESS + rbAdr,rbSize) == Master4.ku8MBSuccess) {    
  for(int i = 0; i < rbSize; i++) {
    uint8_t index = i/16;
    rbdata[i] = bitRead(Master4.getResponseBuffer(index),i%16);
  }
  memcpy(&rData.bit4,rbdata,rbSize);   
  }

  // Wrtie Bit Data
  const uint8_t wbAdr =rbSize;
  const uint8_t wbSize =sizeof(rData.bit4)-rbSize;
  uint16_t wbWSize = wbSize/16 +1;
  bool wbdata[wbSize];
  uint16_t wbWdata[wbWSize];
  
  memcpy(wbdata,(uint16_t)&rData.bit4 + wbAdr,wbSize);
  for(int i = 0; i < wbSize; i++) {
    uint8_t index1 = i/16;
    uint8_t index2 =  i%16;    
    bitWrite(wbWdata[index1],index2,wbdata[i]);
  }
  for(int i = 0; i < wbWSize; i++) {
    Master4.setTransmitBuffer(i,wbWdata[i]);
  }
  Master4.writeMultipleCoils(BIT_SLAVE4_ADDRESS + wbAdr,wbSize);

  // Read Word Data
  const uint8_t rwAdr =0;
  const uint8_t rwSize = DATA_SLAVE4_READSIZE;
  uint16_t rwdata[rwSize];

  if(Master4.readHoldingRegisters(DATA_SLAVE4_ADDRESS + rwAdr,rwSize) == Master4.ku8MBSuccess) {    
    for(int i = 0; i < rwSize; i++) {
      rwdata[i] = Master4.getResponseBuffer(i);
    }
    memcpy(&rData.Word4,rwdata,rwSize*2);    
  }

  // Write Word Data
  const uint8_t wwAdr =rwSize;
  const uint8_t wwSize =sizeof(rData.Word4)/2-rwSize;
  uint16_t wwdata[wwSize];

  memcpy(wwdata,(uint16_t)&rData.Word4 + wwAdr*2,wwSize*2);
  for(int i = 0; i < wwSize; i++) {
    Master4.setTransmitBuffer(i,wwdata[i]);
  }
  Master4.writeMultipleRegisters(DATA_SLAVE4_ADDRESS + wwAdr,wwSize);
}

/*******************************************************************************************
 * Slave5
*******************************************************************************************/
void mbMaster::ProcessSlave5() {

  // Read Bit Data 
  const uint8_t rbAdr =0;
  const uint8_t rbSize =BIT_SLAVE5_READSIZE;
  bool rbdata[rbSize];   

  if(Master5.readCoils(BIT_SLAVE5_ADDRESS + rbAdr,rbSize) == Master5.ku8MBSuccess) {    
  for(int i = 0; i < rbSize; i++) {
    uint8_t index = i/16;
    rbdata[i] = bitRead(Master5.getResponseBuffer(index),i%16);
  }
  memcpy(&rData.bit5,rbdata,rbSize);   
  }

  // Wrtie Bit Data
  const uint8_t wbAdr =rbSize;
  const uint8_t wbSize =sizeof(rData.bit5)-rbSize;
  uint16_t wbWSize = wbSize/16 +1;
  bool wbdata[wbSize];
  uint16_t wbWdata[wbWSize];
  
  memcpy(wbdata,(uint16_t)&rData.bit5 + wbAdr,wbSize);
  for(int i = 0; i < wbSize; i++) {
    uint8_t index1 = i/16;
    uint8_t index2 =  i%16;    
    bitWrite(wbWdata[index1],index2,wbdata[i]);
  }
  for(int i = 0; i < wbWSize; i++) {
    Master5.setTransmitBuffer(i,wbWdata[i]);
  }
  Master5.writeMultipleCoils(BIT_SLAVE5_ADDRESS + wbAdr,wbSize);

  // Read Word Data
  const uint8_t rwAdr =0;
  const uint8_t rwSize = DATA_SLAVE5_READSIZE;
  uint16_t rwdata[rwSize];

  if(Master5.readHoldingRegisters(DATA_SLAVE5_ADDRESS + rwAdr,rwSize) == Master5.ku8MBSuccess) {    
    for(int i = 0; i < rwSize; i++) {
      rwdata[i] = Master5.getResponseBuffer(i);
    }
    memcpy(&rData.Word5,rwdata,rwSize*2);    
  }

  // Write Word Data
  const uint8_t wwAdr =rwSize;
  const uint8_t wwSize =sizeof(rData.Word5)/2-rwSize;
  uint16_t wwdata[wwSize];

  memcpy(wwdata,(uint16_t)&rData.Word5 + wwAdr*2,wwSize*2);
  for(int i = 0; i < wwSize; i++) {
    Master5.setTransmitBuffer(i,wwdata[i]);
  }
  Master5.writeMultipleRegisters(DATA_SLAVE5_ADDRESS + wwAdr,wwSize);
}
